# %%
# Gruppe 01
# Kossatz   476046
# Marx      465807
# Pham      481509
# Schade    465926

import numpy as np 
import matplotlib.pyplot as plt
from make_domain import make_domain
import matrepr as mtr
from matplotlib.colors import ListedColormap
import matplotlib.animation as animation
from matplotlib.animation import FFMpegWriter
from tqdm.autonotebook import tqdm

# Definiert das Theme für die Plotausgaben
plt.style.use('dark_background')

# Nachfolgend werden Funktionen für die 5 Schritte der numerischen Simulation definiert diese werden dann in der
# Funktion NumSimHA5() aufgerufen. Die 5 Schritte sind wie in der Übung gegliedert in:
# I. Initialiseren
# II. Streaming Step
# III. Berechnung von Dichte und Geschwindigkeit
# IV. Berechnung der GGW-Verteilungsdichte
# V. Kollision - Berechnung der Verteilungsdichte nach dem Stoß

# I. Initialisieren
def Initialisator(geometrie: np.ndarray, u: float) -> np.ndarray:
    """
    Liest die Geometrie ein und initialisiert das N_Gitter in dem die Verteilungsdichten der Knoten
    nach Übungsfolien 3-4 im Equilibriums Zustand gespeichert werden. 
    Bestimmt anschließend die Verteilungsdichte für die konstante Einströmung am linken Rand.

    Args:
        geometrie (np.ndarray): Geometrie des Objekts als 2D Boolean Array, False = leerer Raum, True = Festkörper
        u (float): Einströmgeschwindigkeit des Gases 

    Returns:
        np.ndarray: Initialisiertes N_gitter mit den initialen Verteilungsdichten der Form mxnxalpha bzw (mxnx9).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.
              Knotenpunkte, bei denen die vorgegebene Geometrie existiert, werden mit Nullen initialisiert.
    """
    
    # Es werden 9 mxn Matrizen erstellt, diese enthalten die Startverteilungsdichten je nach alpha Wert (→ eine mxn Matrix pro alpha)
    # alpha = 9 entspricht dem Wert in der Mitte eines Knotens, um mit der 0-Indizierung von Python Arrays die
    # Nummerierung der restlichen Einheitsvektoren, sowie Verteilungsdichten kohärent zur Übung zu halten,
    # wird die Matrix für alpha = 9 in der nachfolgenden N_gitter Matrix an die 0. Stelle gesetzt.
    # D.h. alle Richtungen, die nicht die Mitte sind, gleichen der Nummerierung aus den Übungsfolien.

    # Berechnung der Startverteilungsdichten mithilfe des Gewichtungsfaktors: ------------------------------------------
    # Der Gewichtungsfaktor t_alpha ist gegeben für
    # alpha 1 bis 4: = 1/9
    # für alpha 5 bis 8: = 1/36
    # und für alpha 9: = 4/9

    # Erstellen und Verknüpfen der 9 mxn Matrizen anhand der oben genannten Forderungen
    N_gitter = np.concatenate([np.full((m, n, 1), 4 / 9)] * 1
                              + [np.full((m, n, 1), 1 / 9)] * 4
                              + [np.full((m, n, 1), 1 / 36)] * 4, axis=2)

    # Multipliziere jede alpha Dimension des N_gitters mit der invertierten Geometrie, sodass die Verteilungsdichten an
    # den Stellen wo sich ein Festkörper (geometrie == 1) befindet 0 sind.
    # ('~' invertiert die booleschen Werte in der Geometrie und 'np.newaxis' fügt eine Dimension hinzu,
    #  damit die geometrie und das N_gitter die gleiche Dimension haben und multipliziert werden können)
    # N_gitter = N_gitter * ~geometrie[:, :, np.newaxis]  # ToDo: Geometrie wieder einkommentieren
    N_gitter[4,4,:] = 0
    
    # Die Einströmgeschwindigkeit wird als Vektor mit m Einträgen dargestellt, der erste und letzte Eintrag,
    # sollen dabei nach Aufgabenstellung =0 sein.
    u_gitter = np.full((m), u)
    u_gitter[0] = 0
    u_gitter[-1] = 0

    # Um die Verteilungsdichten für den linken Rand (die konstante Einströmung) zu bestimmen, wird eine aktualisierte
    # Dichte des Gitters (bzw. der ersten Spalte) benötigt. Die nachfolgende Formel folgt aus den Übungsfolien.
    dichte_gitter_erste_spalte = 1 / (1 - u_gitter) * (N_gitter [:,0,2] + N_gitter [:,0,4] + N_gitter [:,0,0]
                                                + 2* ( N_gitter [:,0,3] + N_gitter [:,0,6] + N_gitter [:,0,7]))

    # Verteilungsdichte für die erste Spalte (den linken Rand) bestimmen
    N_gitter[:, 0, 1] = N_gitter[:, 0, 3] + 2/3 * dichte_gitter_erste_spalte * u_gitter  # N_1
    N_gitter[:, 0, 5] = 1/6 * dichte_gitter_erste_spalte * u_gitter + N_gitter[:, 0, 7] - N_gitter[:, 0, 2]/2 + N_gitter[:, 0, 4]/2   # N_5  
    N_gitter[:, 0, 8] = 1/6 * dichte_gitter_erste_spalte * u_gitter + N_gitter[:, 0, 6] - N_gitter[:, 0, 4]/2 + N_gitter[:, 0, 2]/2   # N_8

    return N_gitter


# II. Streaming Step
def bewege_verteilungsdichten(N_gitter: np.ndarray, u: float, bb_mask: np.ndarray) -> np.ndarray:
    """
    Bewegt die Verteilungsdichten nach Übungsfolie 5. über Knoten hinweg. Es werden ebenfalls die konstante Einströmung
    am linken Rand, die Bounce Back Bedingungen für die obere und untere Wand, sowie für die Geometrie und eine Do-Nothing
    Bedingung für die rechte Seitenwand des Kanals implementiert.
    
    Args:
        N_gitter (np.ndarray): Aktuelles Gitter mit Verteilungsdichten der Form mxnxalpha bzw (mxnx9).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.
        u (float): Einströmgeschwindigkeit des Gases
        bb_mask (np.ndarray): 2D-Boolean-Array, das die Geometrie für die Bounce Back Bedingungen als True enthält.

    Returns:
        np.ndarray: Aktualisiertes N_gitter der Form (mxnx9), auf dem die Verteilungsdichten der Knoten nach dem
            Streaming Step (Ausbreitungsschritt) gespeichert werden.
    """
    # Nachfolgend werden die Verteilungsdichten an die nächsten Knoten weitergeben.
    # Um die Randbedingungen zu implementieren wird zunächst in den ersten beiden Dimensionen
    # ein Rand von 0en um das Gitter gelegt
    N_gitter = np.pad(N_gitter, pad_width=((1, 1), (1, 1), (0, 0)), mode='constant', constant_values=0)
    
    # Implementierung der Do-Nothing Bedingung am rechten Rand
    N_gitter[1:-1,-1, 3] = N_gitter[1:-1,-2, 3]     # N3
    N_gitter[1:-1, -1, 7] = N_gitter[:-2, -2, 7]    # N7
    N_gitter[1:-1, -1, 6] = N_gitter[2:, -2, 6]     # N6

    # Bewege die Verteilungsdichten in ihre jeweiligen Richtungen
    N_gitter[:,:,1] = np.roll(N_gitter[:,:, 1], 1, axis=1) # Bewege die alpha = 1 Verteilungsdichte um eins nach rechts
    N_gitter[:,:,2] = np.roll(N_gitter[:,:, 2], 1, axis=0) # Bewege die alpha = 2 Verteilungsdichte um eins nach unten
    N_gitter[:,:,3] = np.roll(N_gitter[:,:, 3], -1, axis=1)     # Bewege die alpha = 3 Verteilungsdichte um eins nach links
    N_gitter[:,:,4] = np.roll(N_gitter[:,:, 4], -1, axis=0)     # Bewege die alpha = 4 Verteilungsdichte um eins nach oben
    
    N_gitter[:,:,5] = np.roll(N_gitter[:,:, 5], (1,1), axis=(0,1))   # Bewege die alpha = 5 Verteilungsdichte um eins nach rechts unten
    N_gitter[:,:,6] = np.roll(N_gitter[:,:, 6], (1,-1), axis=(0,1))  # Bewege die alpha = 6 Verteilungsdichte um eins nach links unten
    N_gitter[:,:,7] = np.roll(N_gitter[:,:, 7], (-1,-1), axis=(0,1)) # Bewege die alpha = 7 Verteilungsdichte um eins nach links oben
    N_gitter[:,:,8] = np.roll(N_gitter[:,:, 8], (-1,1), axis=(0,1))  # Bewege die alpha = 8 Verteilungsdichte um eins nach rechts oben

    
    # Bounce Back Bedingungen für die Geometrie und oberen sowie unteren Rand bestimmen:
    # 'geometrie_overflow' fängt die Verteilungsdichten ab, wo die Strömung in die Geometrie "hineinfließen" würde, 
    # um diese im nächsten Schritt "reflektieren" zu können (Bounce-Back Bedingung).

    geometrie_overflow = np.where(bb_mask[:, :, np.newaxis], N_gitter, 0)
    
    # Addiere die alpha = 3 Verteilungsdichte des Festkörpers zur alpha = 1 Verteilungsdichte des Gitters am Knoten rechts davon
    N_gitter[:,:,1] += np.roll(geometrie_overflow[:,:,3], 1, axis=1)
    # Addiere die alpha = 4 Verteilungsdichte des Festkörpers zur alpha = 2 Verteilungsdichte des Gitters am Knoten unterhalb davon
    N_gitter[:,:,2] += np.roll(geometrie_overflow[:,:,4], 1, axis=0)
    # Addiere die alpha = 1 Verteilungsdichte des Festkörpers zur alpha = 3 Verteilungsdichte des Gitters am Knoten links davon 
    N_gitter[:,:,3] += np.roll(geometrie_overflow[:,:,1], -1, axis=1)
    # Addiere die alpha = 2 Verteilungsdichte des Festkörpers zur alpha = 4 Verteilungsdichte des Gitters am Knoten oberhalb davon 
    N_gitter[:,:,4] += np.roll(geometrie_overflow[:,:,2], -1, axis=0)
    
    # Addiere die alpha = 7 Verteilungsdichte des Festkörpers zur alpha = 5 Verteilungsdichte des Gitters am Knoten rechts unten davon
    N_gitter[:,:,5] += np.roll(geometrie_overflow[:,:,7], (1,1), axis=(0,1))
    # Addiere die alpha = 8 Verteilungsdichte des Festkörpers zur alpha = 6 Verteilungsdichte des Gitters am Knoten links unten davon  
    N_gitter[:,:,6] += np.roll(geometrie_overflow[:,:,8], (1,-1), axis=(0,1))
    # Addiere die alpha = 5 Verteilungsdichte des Festkörpers zur alpha = 7 Verteilungsdichte des Gitters am Knoten links oben davon
    N_gitter[:,:,7] += np.roll(geometrie_overflow[:,:,5], (-1,-1), axis=(0,1))
    # Addiere die alpha = 6 Verteilungsdichte des Festkörpers zur alpha = 8 Verteilungsdichte des Gitters am Knoten rechts oben davon
    N_gitter[:,:,8] += np.roll(geometrie_overflow[:,:,6], (-1,1), axis=(0,1))
    
        
    # Dort wo bb_mask True ist, werden die Verteilungsdichten der Knoten auf 0 gesetzt.
    # Ansonsten bleiben die aktualisierten Verteilungsdichten der Knoten erhalten. 
    # Der Flügel und der untere und obere Rand "enthalten" also keine Strömung mehr.
    N_gitter = np.where(bb_mask[:, :, np.newaxis], 0, N_gitter)

    # Entfernen der Paddings, sorgt für Einhaltung der Do-Nothing Bedingung am rechten Rand, 
    # da ausgeströmte Verteilungsdichten gelöscht werden
    N_gitter = N_gitter[1:-1, 1:-1, :]
    

    # Die Einströmgeschwindigkeit wird als Vektor mit m Einträgen dargestellt, der erste und letzte Eintrag soll 
    # nach Aufgabenstellung =0 sein
    u_gitter = np.full((m), u)
    u_gitter[0] = 0
    u_gitter[-1] = 0

    # Bestimmen der Dichte der ersten Spalte im Gitter, um anschließend die neuen Verteilungsdichten nach der Einströmung zu berechnen
    dichte_gitter_erste_spalte = 1 / (1 - u_gitter) * (N_gitter [:,0,2] + N_gitter [:,0,4] + N_gitter [:,0,0]
                                                + 2* ( N_gitter [:,0,3] + N_gitter [:,0,6] + N_gitter [:,0,7]))

    # Verteilungsdichte für den linken Rand bestimmen
    N_gitter[:, 0, 1] = N_gitter[:, 0, 3] + 2/3 * dichte_gitter_erste_spalte * u_gitter  # N_1
    N_gitter[:, 0, 5] = 1/6 * dichte_gitter_erste_spalte * u_gitter + N_gitter[:, 0, 7] - N_gitter[:, 0, 2]/2 + N_gitter[:, 0, 4]/2   # N_5  
    N_gitter[:, 0, 8] = 1/6 * dichte_gitter_erste_spalte * u_gitter + N_gitter[:, 0, 6] - N_gitter[:, 0, 4]/2 + N_gitter[:, 0, 2]/2   # N_8
    
    return N_gitter

# III. Berechnung von Dichte und Geschwindigkeit
def aktualisiere_dichte(N_gitter: np.ndarray) -> np.ndarray:
    """
    Bestimmt die Dichte an jedem Knotenpunkt des N_gitters und speichert diese in einem 2D numpy Array.
    Nach Übungsfolie 6.

    Args:
        N_gitter (np.ndarray): Gitter auf dem die Verteilungsdichten der Knoten gespeichert werden in der Form (mxnx9).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.

    Returns:
        np.ndarray: 2D Array der Form (mxn) in dem die Dichte an jedem Knotenpunkt als Float gespeichert ist.
    """
    # Berechnung der Dichte
    # axis = len(N_gitter.shape)-1 erlaubt die Summierung über die letzte Dimension, egal wie viele Dimensionen N_gitter hat
    # Spart Rechenzeit im Vergleich zu einem festen Wert wie z.B axis=2, da auch Slices des N_gitter übergeben werden können
    
    dichte_gitter = np.sum(N_gitter, axis=(len(N_gitter.shape)-1)) 
    
    return dichte_gitter


def aktualisiere_geschwindigkeit(N_gitter: np.ndarray, dichte_gitter: np.array, geometrie:np.array) -> np.ndarray:
    """
    Bestimmt die Geschwindigkeit an jedem Knotenpunkt des N_gitters und speichert diese in einem 3D numpy Array.
    Orientiert an Übungsfolie 6.

    Args:
        N_gitter (np.ndarray): Gitter auf dem die Verteilungsdichten der Knoten gespeichert werden der Form (mxnx9).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.

        dichte-gitter (np.ndarray): 2D Array der Form (mxn) in dem die Dichte an jedem Knotenpunkt als Float gespeichert ist.
        
        geometrie (np.ndarray): Geometrie des Objekts als 2D Boolean Array, False = leerer Raum, True = Festkörper


    Returns:
        np.ndarray: 3D numpy Array der Form (mxnx2).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die Geschwindigkeit des Gases an diesem Knoten als 2D Vektor(in x und y Richtung).
    """
    
    # Berechnet die Geschwindigkeit an jedem Knotenpunkt anhand der Einheitsvektoren e_schlange

    # Gittervertor definieren (Achtung: die Nummerierung der Richtung ist gegen den Uhrzeigersinn!)
    e_schlang = np.array([
        [0, 0],  # Richtung 0
        [1, 0], [0, 1], [-1, 0], [0, -1],  # Richtungen 1-4, 
        [1, 1], [-1, 1], [-1, -1], [1, -1]  # Richtungen 5-8
    ], dtype=np.float64)
    
    # Berechne die Geschwindigkeit unter Verwendung der Einsteinschen-Summenkonvention,
    # sprich: jede Verteilungsdichte wird mit dem zugehörigen Einheitsvektor multipliziert und aufsummiert.
    # (N_gitter.shape = (m,n,9), e_schlang.shape = (9,2))
    geschwindigkeit_gitter = np.einsum('ijk,kl->ijl', N_gitter, e_schlang)
    # Dividieren der Geschwindigkeit durch die Dichte an jedem Knotenpunkt außerhalb der Geometrie (~geometrie = nicht Geometrie)
    geschwindigkeit_gitter[~geometrie] /= dichte_gitter[~geometrie][:, np.newaxis]
    # Wo sich die Geometrie befindet, wird die Geschwindigkeit in x und y Richtung auf 0 gesetzt
    geschwindigkeit_gitter[geometrie] = 0
    
    return geschwindigkeit_gitter


# IV. Berechnung der GGW-Verteilungsdichte
def bestimme_equilibrium(dichte_gitter: np.ndarray, geschwindigkeit_gitter: np.ndarray) -> np.ndarray:
    """
    Bestimmt die Gleichgewichtsverteilungsdichten für den aktuellen Zeitschritt an jedem Knotenpunkt des N_gitters und
    speichert diese in einem 3D numpy Array. Die Verteilungsdichten werden für den Kollisionsschritt gebraucht.
    Orientiert an Übungsfolie 6.

    Args:
        dichte_gitter (np.ndarray): 2D Array der Form (mxn) in dem die Dichte an jedem Knotenpunkt als Float gespeichert ist.

        geschwindigkeit_gitter (np.ndarray): 3D Array der Form (mxnx2).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die Geschwindigkeit des Gases an diesem Knoten als 2D Vektor (in x und y Richtung).

    Returns:
        np.ndarray: 3D numpy Array der Form (mxnx9) in dem die Equilibriums Verteilungsdichten der Knoten, 
        für den aktuellen Zeitschritt gespeichert sind.
    """
    # Berechnet die Gleichgewichtsverteilungsdichten für den aktuellen Zeitschritt

    # Gittervertor definieren (Achtung: die Nummerierung der Richtung ist gegen den Uhrzeigersinn!)
    e_schlang = np.array([
        [0, 0],  # Richtung 0
        [1, 0], [0, 1], [-1, 0], [0, -1],  # Richtungen 1-4, 
        [1, 1], [-1, 1], [-1, -1], [1, -1]  # Richtungen 5-8
    ], dtype=np.float64)

    # Gewichtungenfaktor t_alpha für die verschiedenen Richtungen -> t_alpha hat die Form (9 x 1)
    t_alpha = np.array([4 / 9] + [1 / 9] * 4 + [1 / 36] * 4)

    # Ergebnis-Array für die Gleichgewichtsverteilungsdichten
    N_eq_gitter = np.zeros((m, n, 9))
    
    # Berechnung der Gleichgewichtsverteilungsdichten anhand der von alpha abhängigen Einheitsvektoren und Gewichtungsfaktoren
    for alpha in range(9):
        e_alpha = e_schlang[alpha]

        # Skalarprodukte: v·e_alpha und |v|^2
        v_dot_e = np.sum(geschwindigkeit_gitter * e_alpha, axis=2)
        
        v_dot_v = np.sum(geschwindigkeit_gitter ** 2, axis=2)
        

        # Gleichung für N_eq: rho * t_alpha * (1 + 3*v·e_alpha + 9/2*(v·e_alpha)^2 - 3/2*|v|^2)
        N_eq_gitter[:, :, alpha] = dichte_gitter * t_alpha[alpha] * (
                1 + 3 * v_dot_e  - (3 / 2) * v_dot_v + (9 / 2) * (v_dot_e ** 2)
        )
        
    return N_eq_gitter


# V. Kollision: Berechnung der Verteilungsdichte nach dem Stoß
def kollisions_update(N_gitter: np.ndarray, N_eq_gitter: np.ndarray, xi: float) -> np.ndarray:
    """
    Updatet die Verteilungsdichten des N_gitters nach einem Kollisionsschritt. Kollisionsupdate nach Tutoriumsfolie 6.

    Args:
        N_gitter (np.ndarray): Gitter auf dem die Verteilungsdichten der Knoten gespeichert werden der Form (mxnx9).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.
        
        N_eq_gitter (np.ndarray): Gitter auf dem die Gleichgewichtsverteilungsdichten der Knoten gespeichert werden,
            der Form (mxnx9). Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der 
             Knoten repräsentieren. Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.
        
        xi (float): Relaxationsparameter

    Returns:
        np.ndarray: geupdatetes N_gitter mit Verteilungsdichten nach Stoß der Form (mxnx9)
    """
    # Berechne die Verteilungsdichten nach dem Stoß
    N_gitter = N_gitter - (1/xi) * (N_gitter - N_eq_gitter)

    return N_gitter


# Funktionen für das Erstellen der Plots
def plotter(geschw_gitter: np.ndarray, geometrie: np.ndarray, X, Y, ax, step_size, cmap, short_X, short_Y, vmin, vmax) -> None:
    """
    Ersellt Plotobjekte der Geschwindigkeitsverteilung im Kanal als 2 in 1 Plot(Heatmap und Quiverplot). Gibt Plot Objekte zurück, 
    welche zur ertellung von Animationen genutzt werden können. Nimmt Plot Parameter als Variablen entgegen, damit sie 
    nicht in jeder Itteration neu berechnet werden müssen.

    Args:
        geschwindigkeit_gitter (np.ndarray): 3D Array der Form (mxnx2).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die Geschwindigkeit des Gases an diesem Knoten als 2D Vektor.
        geometrie (np.ndarray): 2D Boolean Array welches zum Maskieren der Geometrie verwendet wird.
        X (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der Knoten in x-Richtung.
        Y (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der Knoten in y-Richtung.
        ax (matplotlib.axes._subplots.AxesSubplot): Achsenobjekt auf dem der Plot erstellt wird.
        step_size (int): Schrittgröße für den Abstand zwichen Pfeilen im Quiverplot.
        cmap (ListedColormap): Farbpalette für den contourfill plot.
        short_X (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der zu plottenden Pfeile in x-Richtung.
        short_Y (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der Pfeile zu plottenden in y-Richtung.
        
    Returns:
        heatmap (matplotlib.contour.QuadContourSet): Objekt des Heatmap (contourf()) Plots.
        quiv (matplotlib.quiver.Quiver): Objekt des Quiverplots.
        geo (matplotlib.contour.QuadContourSet): Objekt des Geometrie (contourf()) Plots.
        ax (matplotlib.axes._subplots.AxesSubplot): Achsenobjekt auf dem der Plot erstellt wurde.
    """
    # Erstelle eine tiefe Kopie der Geschwindigkeitsverteilung, damit die Originaldaten nicht verändert werden
    geschwindigkeit_gitter = np.copy(geschw_gitter)

    # Berechne den Geschwindigkeitsbetrag, da dieser sich mit jedem Zeitschritt ändert
    geschwindigkeit_betrag = np.sqrt(geschwindigkeit_gitter[:, :, 0]**2 + geschwindigkeit_gitter[:, :, 1]**2)

    # Erstelle einen gefüllten Konturplott des Geschwindigkeitsbetrags
    # vmin und vmax werden übergeben, damit die Farbskala in jedem Frame gleich ist
    heatmap = ax.contourf(X, Y, geschwindigkeit_betrag, levels=100, cmap="jet", vmin=vmin, vmax=vmax)
    
    # Pfeile auf Länge 1 normieren
    # geschwindigkeit_gitter[geschwindigkeit_betrag != 0,:] = geschwindigkeit_gitter[geschwindigkeit_betrag != 0,:] / geschwindigkeit_betrag[geschwindigkeit_betrag != 0, np.newaxis]
    geschwindigkeit_gitter[geschwindigkeit_betrag == 0,:] = [0,0]  # Geschwindigkeit in der Geometrie auf 0 setzen
    
    # Quoiverplot der Geschwindigkeitsvektoren ausgewähleter Knoten erstellen
    quiv = ax.quiver(short_X,short_Y,geschwindigkeit_gitter[::step_size,::step_size,0], geschwindigkeit_gitter[::step_size,::step_size,1], angles="xy", scale_units="xy", scale=(0.15/step_size), lw= 0.1)
    
    # Geometrie Weiss färben
    geo = ax.contourf(geometrie, cmap=cmap)

    # Achsentitel und Formatierung
    ax.set_title("Geschwindigkeitsverteilung im Kanal")
    ax.set_xlabel("x-Position")
    ax.set_ylabel("y-Position")
    ax.set_aspect("auto")
    ax.set_ylim(m-1,0)  # setzt die Basis des KOS nach oben links, sehr wichtig
    ax.set_xlim(0,n-1)
    
    return heatmap, quiv, geo, ax


def init_plot(geschw_gitter: np.ndarray, geometrie: np.ndarray, vmin, vmax):
    """
    Erstellt Plotobjekte des Contourfill und Quiverplots für die Geschwindigkeitsverteilung im Kanal. Erstellt Plot Objekte 
    und berechnet Plot Parameter, welche im Zeit Loop von der plotter() Funition verwendet werden.
    
    args:
        geschwindigkeit_gitter (np.ndarray): 3D Array der Form (mxnx2).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die Geschwindigkeit des Gases an diesem Knoten als 2D Vektor.

        geometrie (np.ndarray): 2D Boolean Array welches zum Maskieren der Geometrie verwendet wird.
        
    returns:
        X (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der Knoten in x-Richtung.
        Y (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der Knoten in y-Richtung.
        fig (matplotlib.figure.Figure): Figure Objekt des Plots.
        ax (matplotlib.axes._subplots.AxesSubplot): Achsenobjekt auf dem der Plot erstellt wird.
        step_size (int): Schrittgröße für den Abstand zwichen Pfeilen im Quiverplot.
        cmap (ListedColormap): Farbpalette für den contourfill plot.
        short_X (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der zu plottenden Pfeile in x-Richtung.
        short_Y (np.ndarray): 2D Array der Form (mxn) mit den Ortskoordinaten der Pfeile zu plottenden in y-Richtung.
    """
    # Erstelle eine tiefe Kopie der Geschwindigkeitsverteilung, damit die Originaldaten nicht verändert werden
    geschwindigkeit_gitter = np.copy(geschw_gitter)
    # Extrahiere die Dimensionen des Geschwindigkeitsgitters
    m, n, _ = geschwindigkeit_gitter.shape
    
    # Erstelle ein Gitter für die x und y Werte der Ortskoordinaten
    X, Y = np.meshgrid(np.arange(n), np.arange(m))  # Knoten Koordinaten
    
    # Berechne den Geschwindigkeitsbetrag (Pythagoras)
    geschwindigkeit_betrag = np.sqrt(geschwindigkeit_gitter[:, :, 0]**2 + geschwindigkeit_gitter[:, :, 1]**2)
    
    # Erstelle Figure und Axis Objekte des Plots
    fig, ax = plt.subplots(figsize=(10, 6))

    # Erstelle einen gefüllten Konturplott des Geschwindigkeitsbetrags
    heatmap = ax.contourf(X, Y, geschwindigkeit_betrag, levels=100, cmap="jet", vmin=vmin, vmax=vmax)
    # Erstelle eine Farbskala für den Plot
    cbar = plt.colorbar(heatmap, ax=ax, label="Geschwindigkeitsbetrag")

    max_steps = 20  # Maximale Anzahl an Pfeilen die geplottet werden, damit der Plot auch für große n und m übersichtlich bleibt
    step_size = max(1, len(geschwindigkeit_gitter[:,0]) // max_steps)  # Jedes wievielte Element wird geplottet damit wir max_steps Pfeile haben: step_size
    short_X = X[::step_size, ::step_size]  # short_X und short_Y sind die Ortskoordinaten des Ursprungs der Pfeile, 
    short_Y = Y[::step_size, ::step_size]  # diese kommen nur so oft vor wie wir Pfeile haben

    # Pfeile auf Länge 1 normieren
    #geschwindigkeit_gitter[geschwindigkeit_betrag != 0,:] = geschwindigkeit_gitter[geschwindigkeit_betrag != 0,:] / geschwindigkeit_betrag[geschwindigkeit_betrag != 0, np.newaxis]
    geschwindigkeit_gitter[geschwindigkeit_betrag == 0,:] = [0,0]  # Geschwindigkeit in der Geometrie auf 0 setzen
    # Quoiverplot der Geschwindigkeitsvektoren ausgewähleter Knoten erstellen
    # Länge der Pfeile, skaliert mit der Anzahl der Pfeile: scale=(1/step_size)
    ax.quiver(short_X,short_Y,geschwindigkeit_gitter[::step_size,::step_size,0], geschwindigkeit_gitter[::step_size,::step_size,1], angles="xy", scale_units="xy", scale=(0.15/step_size), lw= 0.1)

    # Colormap für die Geometrie: True (Wo der Flügel ist) = Weiß, False (Wo kein Flügel ist) = Transparent
    cmap = ListedColormap(['none', 'white'])
    # Geometrie Weiss färben
    ax.contourf(geometrie, cmap=cmap)

    # Achsentitel und Formatierung
    ax.set_title("Geschwindigkeitsverteilung im Kanal")
    ax.set_xlabel("x-Position")
    ax.set_ylabel("y-Position")
    ax.set_aspect("auto")
    ax.set_ylim(m-1,0)  # setzt die Basis des KOS nach oben links, sehr wichtig
    ax.set_xlim(0,n-1)

    return X, Y, fig, ax, step_size, cmap, short_X, short_Y


def NumSimHA5(n:int, m:int, K:int):
    """
    Führt eine 2D Strömungssimulation in K Zeitschritten auf einem mxn Gitter um eine Geometrie in einem Kanal mit Hilfe 
    der Lattice Boltzmann Methode durch. Plottet im Anschluss die Geschwindigkeitsverteilung im Kanal und speichert diese 
    als .svg im lokalen Verzeichnis. Optional kann die Animation der Simulation als Dargestellt und als .mp4 im lokalen 
    Verzeichnis gespeichert werden.

    Args:
        n (int): Anzahl der Spalten des Gasgitters inklusive linkem und rechten Rand, 
                    siehe Abbildung 1 in der  Aufgabenstellung
        m (int): Anzahl der Zeilen des Gasgitters ohne oberen und unteren Rand, diese werden durch die Bounce Back 
                    Bedingung simuliert, siehe Abbildung 1 in HA
        K (int): Anzahl der Zeitschritte, die simuliert werden sollen

    Returns:
        None
    """
    # Die Funktion erwartet ein Input des Users in der Konsole ob das am Ende erstellte Bild
    # auch animiert gespeichert werden soll oder nicht. Anschließend wir die Simulation erstellt.
    
    print("\n\nGitter-Boltzmann-Simulation einer Strömung in",K,"Zeitschritten auf einem",m,"x",n,"Gitter um eine " 
            "Geometrie.\n"
            "Die dabei erstellte Graphik wird immer im lokalen Verzeichnis als .svg gespeichert.")
    animieren = input("Soll die Graphik zusätzlich als Animation gezeigt werden?" 
            "\nBitte 'j' für ja oder 'n' für nein eingeben:\n").casefold()
                 
    while True:
        if animieren == "j":
            break

        elif animieren == "n":
            break
        
        else:
            animieren = input("you stupid? 'j' oder 'n':\n").casefold()
            pass


    # ------------------------ Aus der Aufgabenstellung vorgegebene Parameter sowie Startwerte -------------------------
    xi = 2 / 3  # Relaxationsparameter
    u = 0.1     # Einströmungsgeschwindigkeit
    
    # Einlesen der zu umströmenden Geometrie (letztes Argument ist der Anstellwinkel des Flügels, soll 20° sein)
    geometrie = make_domain(n, m, 20)
    
    # Erstellen der Bounce-Back-Maske, gibt im Kollisionsschritt an, wo eine Geometrie mit Bounce-Back Bedingung ist
    bb_mask = geometrie
    bb_mask = np.pad(bb_mask, pad_width=1, mode='constant', constant_values=0)
    bb_mask[0,1:] = True    # Obere Wand 
    bb_mask[-1,1:] = True   # Untere Wand
    
    bild_array = []  # Speichert die Geschwindigkeitsverteilung nach jedem Zeitschritt (nur für die Animation relevant)
    
    #------Nachfolgend werden die Schritte I. einmal und II. bis V. K-mal ausgeführt (Erklärung s. jew. Funktionen)-----
    
    # I. Initialisieren
    N_gitter = Initialisator(geometrie, u)      # Erstellen des initialen N-Gitters
    
    # Erstellen von dichte_gitter sowie geschw_gitter um dieser anschließend der init_plot() Funktion zu übergeben
    dichte_gitter = aktualisiere_dichte(N_gitter)   
    geschw_gitter = aktualisiere_geschwindigkeit(N_gitter, dichte_gitter, geometrie)
    
    # Update Loop des Gitters, endet nach K Zeitschritten
    # Tqdm erstellt Ladebalken welche während der Simulation/Animationserstellung in der Konsole ausgegeben werden
    print("\nSimulation wird durchgeführt...")
    
    # Speichert die Geschwindigkeitsverteilung nach jedem Zeitschritt in einer Liste damit diese anschließend 
    # geplottet werden kann
    geschw_list = []
    
    frame_limiter = 200
    # Behalte immer nur 100 Frames
    if K > frame_limiter:
        fr =K//frame_limiter
    else: 
        fr = 1
    
    for t in tqdm(range(K), colour="green", desc="Fortschritt: "):
        
        # II. Streaming Step
        N_gitter = bewege_verteilungsdichten(N_gitter, u, bb_mask)
        
        # III. Berechnung von Dichte und Geschwindigkeit
        dichte_gitter = aktualisiere_dichte(N_gitter)
        geschw_gitter = aktualisiere_geschwindigkeit(N_gitter, dichte_gitter, geometrie)

        # IV. Berechnung der GGW-Verteilungsdichte
        N_eq_gitter = bestimme_equilibrium(dichte_gitter, geschw_gitter) 

        
        # V. Kollision: Berechnung der Verteilungsdichte nach dem Stoß
        N_gitter = kollisions_update(N_gitter, N_eq_gitter, xi)
        
        # Speichert die Geschwindigkeitsverteilung nach jedem fr-ten Zeitschritt in einer Liste
        if animieren == "j":
            if t % fr == 0:
                geschw_list.append(geschw_gitter)
        
    # Liest die maximalen und minimalen Geschwindigkeitswerte aus der Liste der Geschwindigkeitsverteilungen aus um die
    # Legende richtig zu Skalieren
    # somethin is not working here: 
    vmin = np.min(geschw_list)
    #vmin = 0
    # somethin is not working here: 
    vmax = np.max(geschw_list)
    #vmax = 5
    
    
    # Erstellen der Frames für die Animation falls dies im Input-Befehl angegeben wurde
    if animieren == "j":
        print("\nAnimiert jeden ",fr," ten Frame.") 
        # Erstellen der Plotobjekte für die Animation
        X, Y, fig, ax, step_size, cmap, short_X, short_Y = init_plot(geschw_gitter, geometrie, vmin, vmax) 
        # Iteriert über die Geschwindigkeitsverteilungen und speichert die Plots in bild_array
        print("\nFrames werden erstellt...")
        for geschw_gitter in tqdm(geschw_list, colour="red", desc="Fortschritt: "):
            # Plotter Funktion erstellt die Plots und gibt die Plotobjekte zurück
            cont, quiv, geo, ax = plotter(geschw_gitter, geometrie, X, Y, ax, step_size, cmap, short_X, short_Y, vmin, vmax)
            bild_array.append([cont, quiv, geo])
        

        
        # Speichern der Animation als mp4
        print("\nAnimation wird erstellt...")
        cooles_video = animation.ArtistAnimation(fig, bild_array, interval=20, blit=True, repeat=True)
        print("Animation wurde erstellt, schließen Sie das Fenster um fortzufahren.")
        
        plt.show()

        speichern = input("\nSoll die Animation als .mp4 gespeichert werden?\nBitte 'j' für ja oder 'n' für nein eingeben:\n").casefold()
        while True:
            if speichern == "j":
                break
            elif speichern == "n":
                break
            else:
                speichern = input("you stupid? 'j' oder 'n':\n").casefold()
                pass
        

        if speichern == "j":
            # Darstellen und aktualisieren des Ladebalkens
            print("Error? Mp4 Format nicht erkannt? FFMPEG installiert? Link: https://www.wikihow.com/Install-FFmpeg-on-Windows")
            print("\nAnimation wird gerendert...")
            update_func = lambda _i, _n: progress_bar.update(1)
            with tqdm(total=len(bild_array), colour="red", desc="Fortschritt: ") as progress_bar:
                cooles_video.save(dpi=300, progress_callback=update_func, filename="geschwindigkeitsverteilung.mp4")
            
            print("\nAnimation wurde als .mp4 im lokalen Verzeichnis gespeichert.")
        
        else: 
            pass

        
    plt.clf()   # Figure Inhalt löschen
    plt.close() # Figure Fenster schließen
    init_plot(geschw_gitter, geometrie, vmin, vmax)
    plt.savefig("geschwindigkeitsverteilung.svg", format="svg", bbox_inches="tight")
    print("\n.svg wurde im lokalen Verzeichnis gespeichert.")
    
    plt.show()
    

    
    return None

n = 100
m = 100
K = 1000

NumSimHA5(n, m, K)

# mtr.mdisplay(N_gitter, max_rows = 2*n, max_cols = 2*m)



# %%
