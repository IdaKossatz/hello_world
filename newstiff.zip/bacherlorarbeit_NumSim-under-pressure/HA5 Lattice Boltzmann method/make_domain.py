import numpy as np
from math import cos, sin, radians
from matplotlib import path

def make_domain(n, m, alpha):
    """
    Generates a domain based on NACA airfoil specifications.

    Parameters:
    n, m (int): Dimensions of the domain.
    alpha (float): Angle of attack.

    Returns:
    domain (numpy.ndarray): Boolean array indicating points inside the airfoil.
    """
    # NACA Airfoil specifications
    iaf = {
        "designation": "6412",
        "n": 100,
        "HalfCosineSpacing": 1,
        "wantFile": 1,
        "datFilePath": "./",
        "is_finiteTE": 0
    }

    # Generate airfoil
    af = naca4gen(iaf)

    # Dimensionalize/scale airfoil
    x_crv = n / 5 + np.concatenate((af["xL"], af["xU"])) * n / 6
    y_crv = 3 * m / 5 + np.concatenate((-af["zL"], -af["zU"])) * n / 6

    # Rotation around airfoil origin
    x_crv_rotated = (x_crv - x_crv[0]) * cos(radians(-alpha)) + \
                    (y_crv - y_crv[0]) * sin(radians(-alpha)) + x_crv[0]
    y_crv_rotated = -(x_crv - x_crv[0]) * sin(radians(-alpha)) + \
                    (y_crv - y_crv[0]) * cos(radians(-alpha)) + round(m / 2)

    x_crv, y_crv = x_crv_rotated, y_crv_rotated
    #print(x_crv)

    X, Y = np.meshgrid(np.arange(1, n + 1), np.arange(1, m + 1))
    p = path.Path(np.column_stack((x_crv, y_crv)))
    domain = p.contains_points(np.column_stack((X.flatten(), Y.flatten()))).reshape(X.shape)

    return domain

import numpy as np

def naca4gen(iaf):
    """
    Generates the NACA 4-digit airfoil coordinates with the desired number of panels.

    Parameters:
    iaf (dict): 
        - designation (str): NACA 4-digit designation (e.g., '2412').
        - n (int): Number of panels per side (upper/lower).
        - HalfCosineSpacing (int): 1 for half cosine spacing, 0 for uniform spacing.
        - wantFile (int): 1 to create a data file, 0 to suppress file creation.
        - datFilePath (str): Path for the data file (use forward slashes).
        - is_finiteTE (int): 1 for finite trailing edge thickness, 0 otherwise.

    Returns:
    dict: Airfoil data containing coordinates and metadata.
    """
    # Extract parameters
    t = int(iaf["designation"][2:]) / 100
    m = int(iaf["designation"][0]) / 100
    p = int(iaf["designation"][1]) / 10

    # Constants for thickness distribution
    a0, a1, a2, a3 = 0.2969, -0.1260, -0.3516, 0.2843
    a4 = -0.1015 if iaf["is_finiteTE"] else -0.1036

    # x-spacing
    if iaf["HalfCosineSpacing"] == 1:
        beta = np.linspace(0, np.pi, iaf["n"] + 1)
        x = 0.5 * (1 - np.cos(beta))  # Half cosine spacing
        iaf["header"] = f"NACA {iaf['designation']} : [{2 * iaf['n']} panels, Half cosine x-spacing]"
    else:
        x = np.linspace(0, 1, iaf["n"] + 1)
        iaf["header"] = f"NACA {iaf['designation']} : [{2 * iaf['n']} panels, Uniform x-spacing]"

    # Thickness distribution
    yt = (t / 0.2) * (a0 * np.sqrt(x) + a1 * x + a2 * x**2 + a3 * x**3 + a4 * x**4)

    # Camber line and its derivative
    xc1 = x[x <= p]
    xc2 = x[x > p]
    xc = np.concatenate((xc1, xc2))

    if p == 0:
        # Symmetric airfoil
        xu, yu = x, yt
        xl, yl = x, -yt
        zc = np.zeros_like(xc)
    else:
        # Cambered airfoil
        yc1 = (m / p**2) * (2 * p * xc1 - xc1**2)
        yc2 = (m / (1 - p)**2) * ((1 - 2 * p) + 2 * p * xc2 - xc2**2)
        zc = np.concatenate((yc1, yc2))

        dyc1_dx = (m / p**2) * (2 * p - 2 * xc1)
        dyc2_dx = (m / (1 - p)**2) * (2 * p - 2 * xc2)
        dyc_dx = np.concatenate((dyc1_dx, dyc2_dx))
        theta = np.arctan(dyc_dx)

        xu = x - yt * np.sin(theta)
        yu = zc + yt * np.cos(theta)

        xl = x + yt * np.sin(theta)
        yl = zc - yt * np.cos(theta)

    # Concatenate coordinates
    af = {
        "name": f"NACA {iaf['designation']}",
        "x": np.concatenate((np.flipud(xu), xl[1:])),
        "z": np.concatenate((np.flipud(yu), yl[1:])),
        "xU": np.flipud(xu),
        "zU": np.flipud(yu),
        "xL": xl,
        "zL": yl,
        "xC": xc,
        "zC": zc,
        "rLE": 0.5 * (a0 * t / 0.2)**2
    }

    # Leading edge circle center
    le_offs = 0.5 / 100
    dyc_dx_le = (m / p**2) * (2 * p - 2 * le_offs)
    theta_le = np.arctan(dyc_dx_le)
    af["xLEcenter"] = af["rLE"] * np.cos(theta_le)
    af["yLEcenter"] = af["rLE"] * np.sin(theta_le)

    # Save to file if requested
    if iaf["wantFile"] == 1:
        file_path = f"{iaf['datFilePath']}naca{iaf['designation']}.dat"
        with open(file_path, "w") as file:
            file.write(iaf["header"] + "\n")
            for xi, zi in zip(af["x"], af["z"]):
                file.write(f"{xi:.6f} {zi:.6f}\n")

    return af