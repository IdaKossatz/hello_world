function mySingleRun()
    siz = [50 50]; % grid size
    [N_grid, parameters] = myInit(siz); % init grid (G) and parameters (p)
    t = 0; % current time
    dt = 1; % number of timesteps between plots/communication
    tend = 30; % simulation end time
    
    parameters.velocity_grid = zeros(siz(1), siz(2), 2); % make room for velocity grid in parameters
    while t < tend
        tnew = min( tend , t + dt );
        [N_grid, parameters] = myUpdate(N_grid,parameters,tnew-t); % update rule
        t = tnew;

        myDrawnow(parameters,tnew); % update plot
    end
    
end