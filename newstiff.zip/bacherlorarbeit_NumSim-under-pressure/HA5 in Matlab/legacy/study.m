lines = 100;
cols = 100;
tend = 1000;
dt = 5;
processes = 2;
graphics = 1;

cpucount = 2:11; % number of cpus to test
cps = zeros(1, numel(cpucount)); % preallocate cps array

for i = 1:length(cpucount)
    cps(i) = multi.multicore(lines, cols, tend, 1, cpucount(i), 0); % run multicore with different cpu counts
end
%cpucount = 2:11
%cps = randi(100, 1, length(cpucount)); % random data for testing
plot(cpucount, cps, 'o-'); % plot the results
xlabel('Number of CPUs');
ylabel('CPS (cells per second)');
str = sprintf('Cells per second vs Number of CPUs for a grid of size %d x %d and %d timesteps.', lines, cols, tend);
title(str);

