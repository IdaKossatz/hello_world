function vel = two_D_LBM(rows, cols, time_steps, plotting, loadingbar)
    % todo: since v0 = 1 and rho = 1 as well the intialising step(I.) changes to N_eq=t_alpha and
    %  the density/velocity in III. is calculated without adding v0 and rho, might need to be changed though, for real life purposes...
    xi = 2/3;  % Relaxationparameter
    inlet_speed = 0.1;   % Inlet flowspeed
    angle_of_attack = 20; % Angle of attack
    
    % Read wing geometry from Lars function
    geometry = make_domain(rows, cols, angle_of_attack);

    % Create bounce-back mask
    bb_mask = geometry;
    bb_mask = padarray(bb_mask,[1 1],0,'both');
    bb_mask(1, 2:end) = true;  % walls of the flow channel
    bb_mask(end, 2:end) = true;
    
    % I. Initalization
    N_grid = Initializer(geometry, inlet_speed, rows, cols); % works
    
    if loadingbar == 1
        % create waitbar
        bar = waitbar(0, 'Starting');
    end

    % Update grid for time_steps
    for t = 1:time_steps
        if loadingbar == 1
            % update waitbar
            waitbar(t/time_steps, bar, sprintf('Progress: %d %%', floor(t/time_steps*100)));
        end
        % II. Streaming Step
        N_grid = move_distribution_density(N_grid, inlet_speed, bb_mask, rows); % works

        % III. Calculate density and velocity
        density_grid = calculate_density(N_grid); % works
        
        velocity_grid = calculate_velocity(N_grid, density_grid, geometry, rows, cols); % works

        % IV. Calculate equilibrium distribution density
        N_eq_grid = calculate_equilibrium(density_grid, velocity_grid, rows, cols); % works

        % V. Collision: Calculating of the distribution density after a collision
        N_grid = collision_update(N_grid, N_eq_grid, xi);	
    end

    % Find waitbar tag and delete the waitbar
    F = findall(0,'type','figure','tag','TMWWaitbar');
    delete(F);

    if plotting == 1
        % Plotting
        figure  % open new figure window
        [X, Y] = meshgrid(0:cols-1, 0:rows-1);  % get coordinates for the grid
        abs_velocity = sqrt(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2);  % calculate absolute velocity
        abs_velocity = abs_velocity ./ ~geometry;
        contourf(X, Y, abs_velocity, 100, 'edgecolor','none')  % plot the absolute velocity as a filled contour plot
        set(gca, 'YDir','reverse')
        colormap('jet')
        colorbar()
        xlabel('x-position')
        ylabel('y-position')
        title('Velocity distribution in flow channel')
        hold on
        % FixMe:  to much downsampling for plots of size 10x10 for example
        downsample_factor = fix(cols/20);  % downsample factor for quiver plot
        X = X(1:downsample_factor:end, 1:downsample_factor:end);  % downsample the grid for quiver plot
        Y = Y(1:downsample_factor:end, 1:downsample_factor:end);  % downsample the grid for quiver plot
        d_velocity_grid = velocity_grid(1:downsample_factor:end, 1:downsample_factor:end, :);  % downsample the velocity grid for quiver plot
        quiver(X, Y, d_velocity_grid(:,:,1), d_velocity_grid(:,:,2), 0.5, "black")  % overlay vector field
        hold off
    end
    vel = velocity_grid(fix(rows / 2), fix(cols / 2), 1); % return the velocity at the center of the grid
end

