multiSimParallel()
multiSimThread()


% a)
% führt die 2D_LBM 1000 mal seriell aus und gibt die Zeit für die ausführungen an
function multiSimSerial()
    n = 1e3;
    res = zeros(1,n);
    timeVal = tic;
    for i1 = 1:n
        res(i1) = two_D_LBM(10, 10, 10,0,0); % Call the function with the desired parameters
    end
    dT = toc(timeVal);
    fprintf('Stichprobe: E(X) = %8.3g, n = %8.3g \n' , mean(res) , n );
    fprintf('Zeitbedarf: dT/n = %8.3g, dT = %8.3g \n' , dT/n , dT );
    % clf; histogram(res);
    end

% b)
% führt die 2D_LBM 1000 mal seriell und parallel aus und gibt die Zeit für die ausführungen an
function multiSimThread()
    fprintf('\nsingle thread\n');
    maxNumCompThreads(1);
    multiSimSerial();
    fprintf('\nmulti thread\n');
    maxNumCompThreads('automatic');
    multiSimSerial();
end


% c) 

function multiSimParallel()
    fprintf('\nmulti thread Processes\n');
    obj = gcp('nocreate');
    if isempty(obj)
        parpool('Processes');
    end
    n = 1e3;
    res = zeros(1,n);
    timeVal = tic;
    parfor i1 = 1:n
        res(i1) = two_D_LBM(10, 10, 10,0,0);
    end
    dT = toc(timeVal);
    fprintf('Stichprobe: E(X) = %8.3g, n = %8.3g \n' , mean(res) , n );
    fprintf('Zeitbedarf: dT/n = %8.3g, dT = %8.3g \n' , dT/n , dT );
    % clf; histogram(res);
end