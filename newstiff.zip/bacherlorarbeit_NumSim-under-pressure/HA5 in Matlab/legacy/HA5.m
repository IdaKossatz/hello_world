rows = 10;
cols = 10;
time_steps = 1000;
plotting = 1;
bar = 1;

two_D_LBM(rows, cols, time_steps, plotting, bar)
