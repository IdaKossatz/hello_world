% This file contains the main function for the multicore simulation
% The function multicore() and spmd_main() refer to the myDraw() and myUpdate() functions and also the functions from the 
% classes multi.m and initial.m



function [cps, Grid] = LBM(lines, cols, depth, numcpu, dt, tend, graphics, D, tau, cs, inlet_speed, pressure_in, pressure_out, collision_model)
    % LBM: runs different functions to solve the LB equation based on the choice of numcpu
    % inputs------------------------------------------
    % lines: number of lines in the grid
    % cols: number of columns in the grid
    % numcpu: number of cpu cores to use, 0 = gpu, 1 = single core, >1 = multicore
    % dt: divergence time steps for multicore simulations
    % tend: end time of the simulation
    % graphics: 1 = plot, 0 = no plot, 0 is used for studys
    % returns-----------------------------------------
    % cps: cells per second that where calculated
    % graphics: plots the simulation
    

    if D ~= 2 && D ~= 3
        error('Error: D must be 2 or 3');
    end
    if D == 3
        if numcpu ~= 0
            error('Error: numcpu must be 0 for 3D simulations');
        end
        % clear GPU Memeory, while not speeding up the code (was tested
        % using gputimeit) it allows the user to better monitor gpu memory
        % consumption via taskmanager
        
        reset(gpuDevice);
        fprintf("Using %s \nAvailable Memory for simulation %.4g GB",gpuDevice().Name, gpuDevice().AvailableMemory*(1e-9));
        % initialize 3D grid
        simulation_space_size = gpuArray([lines, cols, depth]);
        tau = gpuArray(tau);  % tau must be a gpuArray for 3D simulations
        cs = gpuArray(cs);  % cs must be a gpuArray for 3D simulations
        inlet_speed = gpuArray(inlet_speed);  % inlet_speed must be a gpuArray for 3D simulations
        tend = gpuArray(tend);
        pressure_in = gpuArray(pressure_in); 
        pressure_out = gpuArray(pressure_out);  

        [Grid, tau, inlet_speed_grid, one_over_1_minus_inspeed, open_end_mask, div_cs_square, inflow_overflow_mask, divs] = D3.myInitGPU(simulation_space_size, tau, cs, inlet_speed); 
        
        % Time tracking
        Device = gpuDevice;
        wait(Device)
        fprintf('\n+ Start %s, %.4g mio cells\n', mfilename , numel(Grid(:,:,:,1:19))/1e6 );  % print amount of cells in grid

        if pressure_in == 0 || pressure_out == 0
            % Velocity boundary condition -------------------------
            fprintf('Using velocity boundary condition\n');
            timeVal = tic;
            [Grid] = D3.myUpdateGPU(Grid, inlet_speed_grid, one_over_1_minus_inspeed, tau, tend, open_end_mask, div_cs_square, inflow_overflow_mask, divs);
            dT = toc(timeVal); % runtime 

        elseif pressure_in ~= 0 && pressure_out ~= 0
            % Pressure boundary condition ------------------------
            fprintf('Using pressure boundary condition\n');
            % A pressure of 1/3 leads to a density of 1
            density_grid_first_col = pressure_in .* div_cs_square;
            density_grid_last_col = pressure_out .* div_cs_square;

            % Define constants to save memory
            density_in_div_18 = gpuArray(1/36*density_grid_first_col);
            density_in_div_36 = gpuArray(1/36*density_grid_first_col);
            density_out_div_18 = gpuArray(1/18*density_grid_last_col);  
            density_out_div_36 = gpuArray(1/36*density_grid_last_col);  
            
            density = gpuArray(zeros(6));
            density(1) = density_grid_first_col;
            density(2) = density_grid_last_col;
            density(3) = density_in_div_18;
            density(4) = density_in_div_36;
            density(5) = density_out_div_18;    
            density(6) = density_out_div_36;
           
            timeVal = tic;

            [Grid] = D3.myUpdateGPU_underPressure(Grid, inlet_speed_grid, one_over_1_minus_inspeed, tau, tend, open_end_mask, div_cs_square, inflow_overflow_mask, divs, density);
            dT = toc(timeVal); % runtime 
        end

        % timeVal = tic;

        % [Grid] = D3.myUpdateGPU(Grid, inlet_speed_grid, one_over_1_minus_inspeed, tau, tend, open_end_mask, div_cs_square, inflow_overflow_mask, divs);

        % Time tracking
        %dT = toc(timeVal); % runtime 
        % GPU sim postprocessing
        wait(Device)
        cps = numel(Grid(:,:,:, 1:19))*tend/dT; % cells per second
        fprintf('+ End, time = %.4g, %.4g mio cells / s\n\n', dT , cps/1e6 );

        if graphics == 1
            D3.myDrawnowGPU(tend, Grid,simulation_space_size); % Plot
        end
    else
        % Start Simulation
        if numcpu == 0  % GPU ----------------------------------------------------------------------------------------------

            % initialize GPU simulation, tau == xi for 2D simulations
            [Grid, xi, inlet_speed_grid, one_over_1_minus_inspeed, open_end_mask] = myInitGPU(gpuArray([lines cols]), tau, inlet_speed);
            Device = gpuDevice;
            wait(Device)

            fprintf('\n+ Start %s, %.4g mio cells\n', mfilename , numel(Grid(:,:,1:9))/1e6 );  % print amount of cells in grid

            timeVal = tic;
            % run GPU simulation
            [Grid] = myUpdateGPU(Grid, inlet_speed_grid, one_over_1_minus_inspeed, xi, tend, open_end_mask); % update rule
            dT = toc(timeVal); % runtime 

            % GPU sim postprocessing
            wait(Device)
            cps = numel(Grid(:,:, 1:9))*tend/dT; % cells per second
            fprintf('+ End, time = %.4g, %.4g mio cells / s\n\n', dT , cps/1e6 );
            if graphics == 1
                myDrawnowGPU(tend, Grid); % Plot
            end



        elseif numcpu > 0  % CPU -------------------------------------------------------------------------------------------
            % initialize CPU simulation, tau == xi for 2D simulations
            [Grid, parameters] = myInit([lines cols], tau, inlet_speed);
            overlap = dt;  % thickness of multicore borders that need to be healed
            time = 0;  % simulation start time
            parameters.plot = 0; % forces myDrawnow to generate initial plot data
            % Generate data that is needed for every plot, does not plot anything
            [parameters] = myDrawnow(parameters,time, Grid);  
            fprintf('\n+ Start %s, %.4g mio cells\n', mfilename , numel(Grid(:,:,1:9))/1e6 );


            if numcpu == 1  % single core ----------------------------------------------------------------------------------

                bar = waitbar(0, 'Please wait ...');  % create loading bar
                timeVal = tic;
                % runsingle core simulation
                for time = 1:tend
                    waitbar(time/tend, bar, sprintf('Progress: %d %%', floor(time/tend*100)));  % update loading bar
                    [Grid, parameters] = myUpdate(Grid,parameters,1); % update rule

                    if graphics == 1  % animate simulation
                        myDrawnow(parameters,time, Grid);
                    end
                end  
                dT = toc(timeVal); % runtime     
                delete(bar); % delete waitbar



            else  % multi core ---------------------------------------------------------------------------------------------

                % setup cpu pool
                % pool: shared 
                pool = gcp('nocreate');  % assign current parallel pool object to pool, if it does not exist,
                %  one is created

                % if the pool is empty, build a cluster using parcluster, assign a number of workers and create a 
                % parallel pool from the cluster
                if isempty(pool)
                    cluster = parcluster; cluster.NumWorkers = numcpu; cluster.parpool(numcpu);
                % if the pool is not empty, check if the number of workers is equal to numcpu, if it is, do nothing, if it
                % is not, delete the pool and create a new one with the correct number of workers in the cluster
                elseif pool.NumWorkers ~= numcpu
                    delete(pool);
                    cluster = parcluster; cluster.NumWorkers = numcpu; cluster.parpool(numcpu);
                end

                % split grid data up for the workers
                [nx,ny,nc] = size(Grid);
                % number columns of the grid per worker are stored in a vector, here the empty vector is created
                nodes = zeros(1,numcpu);
                % distribute columns as evenly as possible between the cpus, also ensures only whole columns are 
                % assigned to workers
                for i2 = 1:numcpu   
                    nodes(i2) = round( (ny - sum(nodes))/(numcpu - i2 + 1) );
                end
                % split the Grid into a cell array, where each cell i holds nodes(i) columns of the grid
                Grid = mat2cell(Grid,nx,nodes,nc); 
                spmd 
                    G_local = Grid{spmdIndex};  % each worker gets a cell from the G_local cell array
                end

                spmd % each worker pads the grid in order to avoid boundary problems      
                    G_local = multi.spmd_nonperiodic_add_space(G_local,overlap);
                end

                % parallel computing


                % Create waitbar
                w = waitbar(0,'Please wait ...');
                % Create DataQueue and listener
                D = parallel.pool.DataQueue;
                % Function that updates the waitbrar when data is sent to the DataQueue
                afterEach(D,@ multi.parforWaitbar);
                multi.parforWaitbar(w,tend*numcpu/dt)

                timeVal = tic;
                spmd % each worker: interchange data and update rule
                    while time < tend
                        tnew = min( tend , time + dt );
                        G_local = multi.spmd_nonperiodic_update(G_local,parameters,tnew-time,overlap); % update rule
                        time = tnew;
                        send(D,[]);  % send empty data to DataQueue to update waitbar
                    end
                end
                dT = toc(timeVal); % runtime
                delete(w); % delete waitbar


                spmd % each worker: remove extra space
                    G_local = multi.spmd_nonperiodic_rem_space(G_local,overlap);
                end

                % gather data from workers
                Grid = ([G_local{:}]);
            end



            if graphics == 1
                myDrawnow(parameters,tend, Grid); % last plot
            end
            cps = numel(Grid(:,:, 1:9))*tend/dT; % cells per second
            fprintf('+ End, time = %.4g, %.4g mio cells / s\n\n', dT , cps/1e6 );
        
        else
            error('Error: numcpu must be 0, 1 or >1');
        end % end gpu -------------------------------------------------------------
    end

end
