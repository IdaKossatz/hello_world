function [Grid] = myUpdateGPU(Grid, inlet_speed_grid, one_over_1_minus_inspeed, xi, tend, open_end_mask)
    % Update rules for the simulation
    % inputs:------------------------------------------
    % Grid: grid with distribution density, velocity and geometry
    % inlet_speed_grid: grid with inlet speed distribution at left side
    % one_over_1_minus_inspeed: grid with 1/(1-inlet_speed) for each cell at the left side
    % xi: relaxation parameter
    % tend: end time of the simulation
    % open_end_mask: grid with open end mask for the outflow/drain condition
    % returns:------------------------------------------
    % Grid: grid with distribution density

    % bar = waitbar(0, 'Please wait ...');
    
    % Timeloop that moves and updates the distribution densities for a given time step dt ------------------------------
        for t = 1:tend
            % II. Streaming Step
            Grid(:,:,1:9) = update.move_distribution_density(Grid(:,:,1:9), inlet_speed_grid, one_over_1_minus_inspeed, Grid(:,:,10), open_end_mask); % works

            % III. Calculate density and velocity
            Grid(:,:,14) = update.calculate_density(Grid(:,:,1:9)); % works

            Grid(:,:,12:13) = update.calculate_velocity(Grid(:,:,1:9), Grid(:,:,14), Grid(:,:,10), Grid(:,:,12:13)); % works

            % IV. Calculate equilibrium distribution density
            Grid(:,:,15:23) = update.calculate_equilibrium(Grid(:,:,14), Grid(:,:,12:13)); % works

            % V. Collision: Calculating of the distribution density after a collision
            Grid(:,:,1:9) = update.collision_update(Grid(:,:,1:9), Grid(:,:,15:23), xi);
        
        % waitbar(t/tend, bar, sprintf('Progress: %d %%', floor(t/tend*100)));
        end
    % delete(bar); % delete waitbar
    
end