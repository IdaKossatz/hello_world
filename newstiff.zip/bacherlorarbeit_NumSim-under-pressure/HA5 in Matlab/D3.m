classdef D3
    methods(Static)
        function [Grid, tau, inlet_speed_grid, one_over_1_minus_inspeed, open_end_mask, div_cs_square, inflow_overflow_mask, divs] = myInitGPU(simulation_space_size, tau, cs, inlet_speed)
            % myInit: initializes the grid and parameters for the simulation as gpuArrays in 3D
            % inputs------------------------------------------
            % : simulation_space_size: size of the grid that is to be initialized as a 1x3 array (x,y,z)
            
            % returns-----------------------------------------
            % Grid: grid with distribution density and ...
            % tau: relaxation parameter
            % inlet_speed_vector: vector with inlet speed from the left (0 means no inlet)
            % one_over_1_minus_inspeed: vector with 1/(1-inlet_speed) (saves repeated division in the loop)
            % open_end_mask: vector with open end mask for the open end condition

            cs_square = cs^2;  % speed of sound in the lattice squared (1/3 * delta_x^2 / delta_t^2)

            inlet_speed_grid = gpuArray(zeros(simulation_space_size(1), 1 , simulation_space_size(3))); 
            inlet_speed_grid(3:end-2, 1, 3:end-2) = 1;  % set inlet speed in the middle of the grid
            inlet_speed_grid(2:end-1, 1, 2:end-1) = 1;
            inlet_speed_grid = inlet_speed_grid .* inlet_speed;  % multiply the inlet speed grid with the inlet speed

            one_over_1_minus_inspeed = 1 ./ (1 - inlet_speed_grid);  % define here to avoid repeated devision in the loop

            bb_mask = gpuArray(true(simulation_space_size));
            
            % Create wing geometry as bounce-back mask (bb_mask) using Lars' function % ToDo: may need changes.
            angle_of_attack = 5; % Angle of attack
            airfoil = gpuArray(initial.make_domain(simulation_space_size(3), simulation_space_size(2), angle_of_attack));
            airfoil = repmat(airfoil,[1 1 simulation_space_size(1)]);
            bb_mask(2:end-1, : , 2:end-1) = false;  % is one where ther is geometry, for example walls
            airfoil = permute(airfoil, [3, 2, 1]);
            airfoil = flip(airfoil,3);
            bb_mask = bb_mask + airfoil;

            % I. Initalization------------------------------------------------------------------------------------------
            % todo: since v0 = 1 and rho = 1 -> N_eq=w_i and the density/velocity in III. is calculated 
            % without adding v0 and rho, might need to be changed though, for real life purposes...

            % The weighting factor w_i is given for -----------------------------------
            % i| 1 to 6: = 1/18
            % i| 7 to 18: = 1/36
            % i| 19: = 1/3
            gpuOnes = gpuArray(ones(simulation_space_size));
            w_1_to_6 = 1/18 .* gpuOnes;
            w_1_to_6 = repmat(w_1_to_6, [1 1 1 6]);

            w_7_to_18 = 1/36 .* gpuOnes;
            w_7_to_18 = repmat(w_7_to_18, [1 1 1 12]);  % repeat the weighting factor for the 12 directions

            w_19 = 1/3 .* gpuOnes;  
            % N_grid = cat(4,repmat( 1/18 .* gpuArray(ones(simulation_space_size)), [1 1 1 6]), ...
            %                repmat( 1/36 .* gpuArray(ones(simulation_space_size)), [1 1 1 12]), ...
            %                1/3 .* gpuArray(ones(simulation_space_size)) ); % concatenate the weighting factors to the grid
            
            N_grid = cat(4, w_1_to_6, w_7_to_18, w_19);  % concatenate the weighting factors to the grid

            % To calculate the distribution densities for the constant inflow at the left boundary, 
            % an updated density of the first coloumn is needed. (The following equation can be found in the script from UE 5)
            density_grid_first_col = 1 ./ (1 - inlet_speed_grid) .* (N_grid(:, 1, :, 1) + N_grid(:, 1, :, 2) ...
                                                        + N_grid(:, 1, :, 5) + N_grid(:, 1, :, 6) + N_grid(:, 1, :, 9) ...
                                                        + N_grid(:, 1, :, 10) + N_grid(:, 1, :, 15) + N_grid(:, 1, :, 16)...
                                                        + N_grid(:, 1, :, 19)...
                                                        + 2 .* (N_grid(:, 1, :, 4) + N_grid(:, 1, :, 8) + N_grid(:, 1, :, 12)...
                                                        + N_grid(:, 1, :, 13) + N_grid(:, 1, :, 18)));
            % 3, 7, 11, 14, 17
            % this should be N_grid() - 2*w_i*rho_W* (c_i cdot u_w) / cs^2, but c_i cdot u_w precalculated to be either
            % + or - inlet_speed
            div_cs_square = gpuArray(1 / cs_square);  % inlet speed divided by cs^2, saves repeated division, more speeeed
            
            % ToDo: Change this to only scalar precalculation if memory is an issue
            % save multiple calculations by declaring the variable a
            a = 2*1/36*density_grid_first_col.*  inlet_speed_grid.* (div_cs_square);

            N_grid(:, 1, :, 3) =  N_grid(:, 1, :, 4)   + 2*1/18*density_grid_first_col.*  inlet_speed_grid.* (div_cs_square) ;
            N_grid(:, 1, :, 7) =  N_grid(:, 1, :, 8)   + a;
            N_grid(:, 1, :, 11) = N_grid(:, 1, :, 12)  + a;
            N_grid(:, 1, :, 14) = N_grid(:, 1, :, 13)  + a;
            N_grid(:, 1, :, 17) = N_grid(:, 1, :, 18)  + a;
            % set all distribution densities to 0, where there is geometry
            % ~bb_mask(:,:) inverts the logical values of the bounce back matrix
            Grid = N_grid .* ~bb_mask; % maybe clear Grid to save memory, but not sure if it is needed ToDo:
            Grid(:,:,:,20) = bb_mask;  % append the geometry bounce back mask to the grid so it can be parallelized
            
            open_end_mask = gpuArray(zeros(simulation_space_size));
            open_end_mask(:, end, :) = 1; % set last y-layer to 1 for open end condition
            open_end_mask = logical(open_end_mask);

            % for the inflow bounce back condition
            inflow_overflow_mask = gpuArray(zeros(size(N_grid)));
            inflow_overflow_mask(2:end-1, :, 2:end-1,:) = 1;

            nine_div_2 = gpuArray(9/2);
            three_div_2 = gpuArray(3/2);

            divs(2) = nine_div_2;
            divs(1) = three_div_2;
            
        end

        function [Grid] = myUpdateGPU(Grid, inlet_speed_grid, one_over_1_minus_inspeed, tau, tend, open_end_mask, div_cs_square, inflow_overflow_mask, divs)
            % myUpdate: updates the grid for the simulation as gpuArrays in 3D
            % inputs------------------------------------------
            % : Grid: grid with distribution density and ...
            % : inlet_speed_grid: vector with inlet speed from the left (0 means no inlet)
            % : one_over_1_minus_inspeed: vector with 1/(1-inlet_speed) (saves repeated division in the loop)
            % : tau: relaxation parameter
            % : tend: end time of the simulation
            % : open_end_mask: vector with open end mask for the open end condition
            
            % returns-----------------------------------------
            % Grid: updated grid with distribution density and ...
            for t = 1:tend
                
                % III. Calculate density and velocity
                Grid(:,:,:,24) = D3.calculate_density(Grid(:,:,:,1:19));

                % using: calculate_velocity(N_grid, density_grid, bb_mask, velocity_grid)
                Grid(:,:,:,21:23) = D3.calculate_velocity(Grid(:,:,:,1:19), Grid(:,:,:,24),  Grid(:,:,:,20), Grid(:,:,:,21:23));
                
                % IV. Calculate equilibrium distribution density and then use it to update the N_grid part of Grid in place
                [Grid(:,:,:,1:19)] = D3.calculate_equilibrium_and_update(Grid(:,:,:,24), Grid(:,:,:,21:23), divs, Grid(:,:,:,1:19), tau);

                 % II. Streaming Step
                 %test 
                 [Grid(:,:,:,1:19), force_grid] = D3.move_distribution_density(Grid(:,:,:,1:19), inlet_speed_grid, one_over_1_minus_inspeed, Grid(:,:,:,20), open_end_mask, div_cs_square, inflow_overflow_mask, Grid(:,:,:,24), Grid(:,:,:,21:23));
                 %Grid(:,:,:,1:19) = D3.move_distribution_density(Grid(:,:,:,1:19), inlet_speed_grid, one_over_1_minus_inspeed, Grid(:,:,:,20), open_end_mask, div_cs_square, inflow_overflow_mask, Grid(:,:,:,24), Grid(:,:,:,21:23));
                 Grid(:,:,:,25:27) = force_grid;
            end
        end

        function [Grid] = myUpdateGPU_underPressure(Grid, inlet_speed_grid, one_over_1_minus_inspeed, tau, tend, open_end_mask, div_cs_square, inflow_overflow_mask, divs, density)
            % myUpdate: updates the grid for the simulation as gpuArrays in 3D
            % inputs------------------------------------------
            % : Grid: grid with distribution density and ...
            % : inlet_speed_grid: vector with inlet speed from the left (0 means no inlet)
            % : one_over_1_minus_inspeed: vector with 1/(1-inlet_speed) (saves repeated division in the loop)
            % : tau: relaxation parameter
            % : tend: end time of the simulation
            % : open_end_mask: vector with open end mask for the open end condition
            
            % returns-----------------------------------------
            % Grid: updated grid with distribution density and ...
            for t = 1:tend
                
                % III. Calculate density and velocity
                Grid(:,:,:,24) = D3.calculate_density(Grid(:,:,:,1:19));

                % using: calculate_velocity(N_grid, density_grid, bb_mask, velocity_grid)
                Grid(:,:,:,21:23) = D3.calculate_velocity(Grid(:,:,:,1:19), Grid(:,:,:,24),  Grid(:,:,:,20), Grid(:,:,:,21:23));
                
                % IV. Calculate equilibrium distribution density and then use it to update the N_grid part of Grid in place
                [Grid(:,:,:,1:19)] = D3.calculate_equilibrium_and_update(Grid(:,:,:,24), Grid(:,:,:,21:23), divs, Grid(:,:,:,1:19), tau);

                 % II. Streaming Step
                Grid(:,:,:,1:19) = D3.move_distribution_density_underPressure(Grid(:,:,:,1:19), inlet_speed_grid, Grid(:,:,:,20), div_cs_square, inflow_overflow_mask, Grid(:,:,:,21:23),density);
            end
        end

        function [N_grid, force_grid] = move_distribution_density(N_grid, inlet_speed_grid, one_over_1_minus_inspeed, bb_mask, open_end_mask, div_cs_square, inflow_overflow_mask, density_grid, velocity_grid)
            % Todo: Do nothing Boundary needs to be adjusted for a pressure boundary condition
            % move_distribution_density: moves the distribution densities in the grid according to the D3 model
            % inputs------------------------------------------
            % : N_grid: grid with distribution density
            % Move the distribution densities in the grid according to the D3 model ------------------------------------
            % Shift for loop was unrolled as advised by Krüger p.69
            N_grid(:,:,:,1) = circshift(N_grid(:,:,:,1), [1 0 0]);
            N_grid(:,:,:,2) = circshift(N_grid(:,:,:,2), [-1 0 0]);
            N_grid(:,:,:,3) = circshift(N_grid(:,:,:,3), [0 1 0]);
            N_grid(:,:,:,4) = circshift(N_grid(:,:,:,4), [0 -1 0]);
            N_grid(:,:,:,5) = circshift(N_grid(:,:,:,5), [0 0 1]);
            N_grid(:,:,:,6) = circshift(N_grid(:,:,:,6), [0 0 -1]);
            N_grid(:,:,:,7) = circshift(N_grid(:,:,:,7), [1 1 0]);
            N_grid(:,:,:,8) = circshift(N_grid(:,:,:,8), [-1 -1 0]);
            N_grid(:,:,:,9) = circshift(N_grid(:,:,:,9), [1 0 1]);
            N_grid(:,:,:,10) = circshift(N_grid(:,:,:,10), [-1 0 -1]);
            N_grid(:,:,:,11) = circshift(N_grid(:,:,:,11), [0 1 1]);
            N_grid(:,:,:,12) = circshift(N_grid(:,:,:,12), [0 -1 -1]);
            N_grid(:,:,:,13) = circshift(N_grid(:,:,:,13), [1 -1 0]);
            N_grid(:,:,:,14) = circshift(N_grid(:,:,:,14), [-1 1 0]);
            N_grid(:,:,:,15) = circshift(N_grid(:,:,:,15), [1 0 -1]);
            N_grid(:,:,:,16) = circshift(N_grid(:,:,:,16), [-1 0 1]);
            N_grid(:,:,:,17) = circshift(N_grid(:,:,:,17), [0 1 -1]);
            N_grid(:,:,:,18) = circshift(N_grid(:,:,:,18), [0 -1 1]);
            % N_grid(:,:,:,19) = circshift(N_grid(:,:,:,19), [0 0 0]);  % no shift for the last distribution density 
                        
            % Do-nothing-boundary-condition at the outflow ------------------------------------------------
            % Save the distribution densities that are in the open end in N_grid_temp so they can be accessed using the open_end_mask
            N_grid_temp = N_grid(:,:,:,4);
            % Reflect outflowing distribution densities at the open end back into the grid where open_end_mask is true
            N_grid_temp(open_end_mask) = N_grid_temp(circshift(open_end_mask, [0 -1 0]));
            % Reassign the reflected distribution densities back to the grid
            N_grid(:,:,:,4) = N_grid_temp;

            % Repeat for the other distribution densities that are in the open end (N_Grid_8, N__Grid_12, N_Grid_13, N_Grid_18)
            N_grid_temp = N_grid(:,:,:,8);
            N_grid_temp(open_end_mask) = N_grid_temp(circshift(open_end_mask, [-1 -1 0]));
            N_grid(:,:,:,8) = N_grid_temp;

            N_grid_temp = N_grid(:,:,:,12);
            N_grid_temp(open_end_mask) = N_grid_temp(circshift(open_end_mask, [0 -1 -1]));  
            N_grid(:,:,:,12) = N_grid_temp;

            N_grid_temp = N_grid(:,:,:,13);
            N_grid_temp(open_end_mask) = N_grid_temp(circshift(open_end_mask, [1 -1 0]));  
            N_grid(:,:,:,13) = N_grid_temp;

            N_grid_temp = N_grid(:,:,:,18);
            N_grid_temp(open_end_mask) = N_grid_temp(circshift(open_end_mask, [0 -1 1]));  
            N_grid(:,:,:,18) = N_grid_temp;
        
            % Implementation for the Bounce-Back-Condition (wall adhesion):---------------------------------------------
            % Used at the geometry (includes the upper and lower channel walls).
            % Saving the distribution densities that would flow into the geometry in order to reflect them
            geometry_overflow = N_grid .* bb_mask;
            N_grid_walls_eq_zero = inflow_overflow_mask .* N_grid;  % apply the inflow_overflow mask to the N_grid

            % Reverse the flow direction of all distribution densities that have flown in to the geometry, and flow them 
            % back out the way they came in, implementing the wall adhesion boundary condition
            % Was rewritten explicitly as advised by Krüger P.69
            N_grid_before_lift = N_grid(:,:,:,1:18); % test

            N_grid(:,:,:,1) =  N_grid(:,:,:, 1) + circshift(geometry_overflow(:,:,:, 2), [1 0 0]);
            N_grid(:,:,:,2) =  N_grid(:,:,:, 2) + circshift(geometry_overflow(:,:,:, 1), [-1 0 0]);
            N_grid(:,:,:,3) =  N_grid(:,:,:, 3) + circshift(geometry_overflow(:,:,:, 4), [0 1 0]);
            N_grid(:,:,:,4) =  N_grid(:,:,:, 4) + circshift(geometry_overflow(:,:,:, 3), [0 -1 0]);
            N_grid(:,:,:,5) =  N_grid(:,:,:, 5) + circshift(geometry_overflow(:,:,:, 6), [0 0 1]);
            N_grid(:,:,:,6) =  N_grid(:,:,:, 6) + circshift(geometry_overflow(:,:,:, 5), [0 0 -1]);
            N_grid(:,:,:,7) =  N_grid(:,:,:, 7) + circshift(geometry_overflow(:,:,:, 8), [1 1 0]);
            N_grid(:,:,:,8) =  N_grid(:,:,:, 8) + circshift(geometry_overflow(:,:,:, 7), [-1 -1 0]);
            N_grid(:,:,:,9) =  N_grid(:,:,:, 9) + circshift(geometry_overflow(:,:,:,10), [1 0 1]);
            N_grid(:,:,:,10) = N_grid(:,:,:,10) + circshift(geometry_overflow(:,:,:,9), [-1 0 -1]);
            N_grid(:,:,:,11) = N_grid(:,:,:,11) + circshift(geometry_overflow(:,:,:,12), [0 1 1]);
            N_grid(:,:,:,12) = N_grid(:,:,:,12) + circshift(geometry_overflow(:,:,:,11), [0 -1 -1]);
            N_grid(:,:,:,13) = N_grid(:,:,:,13) + circshift(geometry_overflow(:,:,:,14), [1 -1 0]);
            N_grid(:,:,:,14) = N_grid(:,:,:,14) + circshift(geometry_overflow(:,:,:,13), [-1 1 0]);
            N_grid(:,:,:,15) = N_grid(:,:,:,15) + circshift(geometry_overflow(:,:,:,16), [1 0 -1]);
            N_grid(:,:,:,16) = N_grid(:,:,:,16) + circshift(geometry_overflow(:,:,:,15), [-1 0 1]);
            N_grid(:,:,:,17) = N_grid(:,:,:,17) + circshift(geometry_overflow(:,:,:,18), [0 1 -1]);
            N_grid(:,:,:,18) = N_grid(:,:,:,18) + circshift(geometry_overflow(:,:,:,17), [0 -1 1]);
            
            N_grid_aft_lift = N_grid(:,:,:,1:18); % test
            P_grid(:, :, :, 1) = N_grid_before_lift(:,:,:,1)  + N_grid_aft_lift(:,:,:,2)  - N_grid_before_lift(:,:,:,2)  - N_grid_aft_lift(:,:,:,1)  + N_grid_before_lift(:,:,:,7)  + N_grid_aft_lift(:,:,:,8) ...
                               - N_grid_before_lift(:,:,:,8)  - N_grid_aft_lift(:,:,:,7)  + N_grid_before_lift(:,:,:,9)  + N_grid_aft_lift(:,:,:,10) - N_grid_before_lift(:,:,:,10) - N_grid_aft_lift(:,:,:,9) ...
                               + N_grid_before_lift(:,:,:,13) + N_grid_aft_lift(:,:,:,14) - N_grid_before_lift(:,:,:,14) - N_grid_aft_lift(:,:,:,13) + N_grid_before_lift(:,:,:,15) + N_grid_aft_lift(:,:,:,16) - N_grid_before_lift(:,:,:,16) + N_grid_aft_lift(:,:,:,15);  % x-velocity

            P_grid(:, :, :, 2) = N_grid_before_lift(:,:,:,3)  + N_grid_aft_lift(:,:,:,4)  - N_grid_before_lift(:,:,:,4)  - N_grid_aft_lift(:,:,:,3)  + N_grid_before_lift(:,:,:,7)  + N_grid_aft_lift(:,:,:,8)  - N_grid_before_lift(:,:,:,8)  - N_grid_aft_lift(:,:,:,7)...
                               + N_grid_before_lift(:,:,:,11) + N_grid_aft_lift(:,:,:,12) - N_grid_before_lift(:,:,:,12) - N_grid_aft_lift(:,:,:,11) - N_grid_before_lift(:,:,:,13) - N_grid_aft_lift(:,:,:,14) + N_grid_before_lift(:,:,:,14) + N_grid_aft_lift(:,:,:,13)...
                               + N_grid_before_lift(:,:,:,17) + N_grid_aft_lift(:,:,:,18) - N_grid_before_lift(:,:,:,18) - N_grid_aft_lift(:,:,:,17);  % y-velocity
            
            P_grid(:, :, :, 3) = N_grid_before_lift(:,:,:,5)  + N_grid_aft_lift(:,:,:,6)  - N_grid_before_lift(:,:,:,6)  - N_grid_aft_lift(:,:,:,5)  + N_grid_before_lift(:,:,:,9)  + N_grid_aft_lift(:,:,:,10) - N_grid_before_lift(:,:,:,10) - N_grid_aft_lift(:,:,:,9)...
                               + N_grid_before_lift(:,:,:,11) + N_grid_aft_lift(:,:,:,12) - N_grid_before_lift(:,:,:,12) - N_grid_aft_lift(:,:,:,11) - N_grid_before_lift(:,:,:,15) - N_grid_aft_lift(:,:,:,16) + N_grid_before_lift(:,:,:,16) + N_grid_aft_lift(:,:,:,15)...
                               - N_grid_before_lift(:,:,:,17) - N_grid_aft_lift(:,:,:,8)  + N_grid_before_lift(:,:,:,18) + N_grid_aft_lift(:,:,:,17);  % z-velocity
            
            angle_of_attack = 5; % Angle of attack
            simulation_space_size = [100 200 16];
            airfoil = gpuArray(initial.make_domain(simulation_space_size(3), simulation_space_size(2), angle_of_attack));
            airfoil = repmat(airfoil,[1 1 simulation_space_size(1)]);
             % is one where there is geometry, for example walls
            airfoil = permute(airfoil, [3, 2, 1]);
            airfoil = flip(airfoil,3);

            force_grid = P_grid .* airfoil ;
        
            % To calculate the distribution densities for the constant inflow at the left boundary,--------------------- 
            % an updated density of the first coloumn is needed. (The following equation can be found in the script from UE 5)
            density_grid_first_col = one_over_1_minus_inspeed .* (N_grid(:, 1, :, 1) + N_grid(:, 1, :, 2) ...
                                                        + N_grid(:, 1, :, 5) + N_grid(:, 1, :, 6) + N_grid(:, 1, :, 9) ...
                                                        + N_grid(:, 1, :, 10) + N_grid(:, 1, :, 15) + N_grid(:, 1, :, 16)...
                                                        + N_grid(:, 1, :, 19)...
                                                        + 2 .* (N_grid(:, 1, :, 4) + N_grid(:, 1, :, 8) + N_grid(:, 1, :, 12)...
                                                        + N_grid(:, 1, :, 13) + N_grid(:, 1, :, 18)));

            % ToDo: Change this to only scalar precalculation if memory is an issue
            % Save multiple calculations by declaring the variable a
            a = 2*1/36*density_grid_first_col.*  inlet_speed_grid.* (div_cs_square);
            
            N_grid(:, 1, :, 3) =  N_grid_walls_eq_zero(:, 1, :, 4)  + 2*1/18*density_grid_first_col.*  inlet_speed_grid.* (div_cs_square) ;
            N_grid(:, 1, :, 7) =  N_grid_walls_eq_zero(:, 1, :, 8)  + a;
            N_grid(:, 1, :, 11) = N_grid_walls_eq_zero(:, 1, :, 12) + a;
            N_grid(:, 1, :, 14) = N_grid_walls_eq_zero(:, 1, :, 13) + a;
            N_grid(:, 1, :, 17) = N_grid_walls_eq_zero(:, 1, :, 18) + a;

            N_grid = N_grid .* ~bb_mask;
            
        end

        function [N_grid] = move_distribution_density_underPressure(N_grid, inlet_speed_grid, bb_mask, div_cs_square, inflow_overflow_mask, velocity_grid, density)
            % Todo: Do nothing Boundary needs to be adjusted for a pressure boundary condition
            % move_distribution_density: moves the distribution densities in the grid according to the D3 model
            % inputs------------------------------------------
            % : N_grid: grid with distribution density
            % Move the distribution densities in the grid according to the D3 model ------------------------------------
            % Shift for loop was unrolled as advised by Krüger p.69
            N_grid(:,:,:,1) = circshift(N_grid(:,:,:,1), [1 0 0]);
            N_grid(:,:,:,2) = circshift(N_grid(:,:,:,2), [-1 0 0]);
            N_grid(:,:,:,3) = circshift(N_grid(:,:,:,3), [0 1 0]);
            N_grid(:,:,:,4) = circshift(N_grid(:,:,:,4), [0 -1 0]);
            N_grid(:,:,:,5) = circshift(N_grid(:,:,:,5), [0 0 1]);
            N_grid(:,:,:,6) = circshift(N_grid(:,:,:,6), [0 0 -1]);
            N_grid(:,:,:,7) = circshift(N_grid(:,:,:,7), [1 1 0]);
            N_grid(:,:,:,8) = circshift(N_grid(:,:,:,8), [-1 -1 0]);
            N_grid(:,:,:,9) = circshift(N_grid(:,:,:,9), [1 0 1]);
            N_grid(:,:,:,10) = circshift(N_grid(:,:,:,10), [-1 0 -1]);
            N_grid(:,:,:,11) = circshift(N_grid(:,:,:,11), [0 1 1]);
            N_grid(:,:,:,12) = circshift(N_grid(:,:,:,12), [0 -1 -1]);
            N_grid(:,:,:,13) = circshift(N_grid(:,:,:,13), [1 -1 0]);
            N_grid(:,:,:,14) = circshift(N_grid(:,:,:,14), [-1 1 0]);
            N_grid(:,:,:,15) = circshift(N_grid(:,:,:,15), [1 0 -1]);
            N_grid(:,:,:,16) = circshift(N_grid(:,:,:,16), [-1 0 1]);
            N_grid(:,:,:,17) = circshift(N_grid(:,:,:,17), [0 1 -1]);
            N_grid(:,:,:,18) = circshift(N_grid(:,:,:,18), [0 -1 1]);
            % N_grid(:,:,:,19) = circshift(N_grid(:,:,:,19), [0 0 0]);  % no shift for the last distribution density 
            
            N_grid_walls_eq_zero = inflow_overflow_mask .* N_grid;

            % Outflow pressure boundary condition ------------------------------------------------------------------
            % the density constants for the outflow pressure condition are already calculated in the main loop 
            % => density(5) = density_out_div_18
            % => density(6) = density_out_div_36; 

            % Velocities/Speeds at the outflow boundary
            outflow_speed_grid = velocity_grid(:, end, :, :) + 0.5 .* (velocity_grid(:,end,:,:) - velocity_grid(:,end-1,:,:));  

            % Velocity squared at the outflow boundary
            outflow_speed_grid_matrix_squared = outflow_speed_grid(:,:,:,1).^2 + outflow_speed_grid(:,:,:,2).^2 + outflow_speed_grid(:,:,:,3).^2;
    
            % Attention: the dot product is written individually for each equation
            N_grid(:, end, :, 4)  = -N_grid_walls_eq_zero(:, end,: , 3)  + density(5) .* (2 +                 outflow_speed_grid(:,:,:,2).^2                  .* div_cs_square.^2 - outflow_speed_grid_matrix_squared .* div_cs_square);
            N_grid(:, end, :, 8)  = -N_grid_walls_eq_zero(:, end,: , 7)  + density(6) .* (2 + (outflow_speed_grid(:,:,:,1)  + outflow_speed_grid(:,:,:,2)).^2 .* div_cs_square.^2 - outflow_speed_grid_matrix_squared .* div_cs_square);
            N_grid(:, end, :, 12) = -N_grid_walls_eq_zero(:, end,: , 11) + density(6) .* (2 + (outflow_speed_grid(:,:,:,2)  + outflow_speed_grid(:,:,:,3)).^2 .* div_cs_square.^2 - outflow_speed_grid_matrix_squared .* div_cs_square);
            N_grid(:, end, :, 13) = -N_grid_walls_eq_zero(:, end,: , 14) + density(6) .* (2 + (-outflow_speed_grid(:,:,:,1) + outflow_speed_grid(:,:,:,2)).^2 .* div_cs_square.^2 - outflow_speed_grid_matrix_squared .* div_cs_square);
            N_grid(:, end, :, 18) = -N_grid_walls_eq_zero(:, end,: , 17) + density(6) .* (2 + (outflow_speed_grid(:,:,:,2)  - outflow_speed_grid(:,:,:,3)).^2 .* div_cs_square.^2 - outflow_speed_grid_matrix_squared .* div_cs_square);
            

            % Implementation for the Bounce Back-Condition (wall adhesion):---------------------------------------------
            % Used at the geometry (includes the upper and lower channel walls).
            % Saving the distribution densities that would flow into the geometry in order to reflect them
            geometry_overflow = N_grid .* bb_mask;

            % Reverse the flow direction of all distribution densities that have flown in to the geometry, and flow them 
            % back out the way they came in, implementing the wall adhesion boundary condition
            % Was rewritten explicitly as advised by Krüger P.69
            N_grid(:,:,:,1) =  N_grid(:,:,:, 1) + circshift(geometry_overflow(:,:,:, 2), [1 0 0]);
            N_grid(:,:,:,2) =  N_grid(:,:,:, 2) + circshift(geometry_overflow(:,:,:, 1), [-1 0 0]);
            N_grid(:,:,:,3) =  N_grid(:,:,:, 3) + circshift(geometry_overflow(:,:,:, 4), [0 1 0]);
            N_grid(:,:,:,4) =  N_grid(:,:,:, 4) + circshift(geometry_overflow(:,:,:, 3), [0 -1 0]);
            N_grid(:,:,:,5) =  N_grid(:,:,:, 5) + circshift(geometry_overflow(:,:,:, 6), [0 0 1]);
            N_grid(:,:,:,6) =  N_grid(:,:,:, 6) + circshift(geometry_overflow(:,:,:, 5), [0 0 -1]);
            N_grid(:,:,:,7) =  N_grid(:,:,:, 7) + circshift(geometry_overflow(:,:,:, 8), [1 1 0]);
            N_grid(:,:,:,8) =  N_grid(:,:,:, 8) + circshift(geometry_overflow(:,:,:, 7), [-1 -1 0]);
            N_grid(:,:,:,9) =  N_grid(:,:,:, 9) + circshift(geometry_overflow(:,:,:,10), [1 0 1]);
            N_grid(:,:,:,10) = N_grid(:,:,:,10) + circshift(geometry_overflow(:,:,:,9), [-1 0 -1]);
            N_grid(:,:,:,11) = N_grid(:,:,:,11) + circshift(geometry_overflow(:,:,:,12), [0 1 1]);
            N_grid(:,:,:,12) = N_grid(:,:,:,12) + circshift(geometry_overflow(:,:,:,11), [0 -1 -1]);
            N_grid(:,:,:,13) = N_grid(:,:,:,13) + circshift(geometry_overflow(:,:,:,14), [1 -1 0]);
            N_grid(:,:,:,14) = N_grid(:,:,:,14) + circshift(geometry_overflow(:,:,:,13), [-1 1 0]);
            N_grid(:,:,:,15) = N_grid(:,:,:,15) + circshift(geometry_overflow(:,:,:,16), [1 0 -1]);
            N_grid(:,:,:,16) = N_grid(:,:,:,16) + circshift(geometry_overflow(:,:,:,15), [-1 0 1]);
            N_grid(:,:,:,17) = N_grid(:,:,:,17) + circshift(geometry_overflow(:,:,:,18), [0 1 -1]);
            N_grid(:,:,:,18) = N_grid(:,:,:,18) + circshift(geometry_overflow(:,:,:,17), [0 -1 1]);
            

            % Inflow pressure boundary condition ---------------------------------------------------
            % the density constants for the outflinflow pressure condition are already calculated in the main loop 
            % => density(3) = density_in_div_18
            % => density(4) = density_in_div_36; 

            N_grid(:, 1, :, 3)  =  -N_grid_walls_eq_zero(:, 1, :, 4)  + density(3) .* (2 + inlet_speed_grid.^2 .* div_cs_square.^2 - inlet_speed_grid.^2 * div_cs_square );
            N_grid(:, 1, :, 7)  =  -N_grid_walls_eq_zero(:, 1, :, 8)  + density(4) .* (2 + inlet_speed_grid.^2 .* div_cs_square.^2 - inlet_speed_grid.^2 .* div_cs_square);
            N_grid(:, 1, :, 11) =  -N_grid_walls_eq_zero(:, 1, :, 12) + density(4) .* (2 + inlet_speed_grid.^2 .* div_cs_square.^2 - inlet_speed_grid.^2 .* div_cs_square);
            N_grid(:, 1, :, 14) =  -N_grid_walls_eq_zero(:, 1, :, 13) + density(4) .* (2 + inlet_speed_grid.^2 .* div_cs_square.^2 - inlet_speed_grid.^2 .* div_cs_square);
            N_grid(:, 1, :, 17) =  -N_grid_walls_eq_zero(:, 1, :, 18) + density(4) .* (2 + inlet_speed_grid.^2 .* div_cs_square.^2 - inlet_speed_grid.^2 .* div_cs_square);
            
            N_grid = N_grid .* ~bb_mask;

        end

        function [density_grid] = calculate_density(N_grid)
            % calculate_density: calculates the density of the grid
            % inputs------------------------------------------
            % N_grid: grid with distribution density
            % returns-----------------------------------------
            % density_grid: grid with density of the grid

            % Note, removing this calculation from a function does not save
            % on VRAM, I tested it.

            % length(size(N_grid)) allows to sum over the last dimension, regardless of the number of dimensions
            density_grid = sum(N_grid, (length(size(N_grid))));

        end

        function [velocity_grid] = calculate_velocity(N_Grid, density_grid, bb_mask, velocity_grid)
            % calculate_velocity: calculates the velocity of the grid
            % inputs------------------------------------------
            % N_grid: grid with distribution density
            % density_grid: grid with density of the grid
            % bb_mask: bounce back mask for the geometry
            % velocity_grid: grid with velocity of the grid
            % returns-----------------------------------------
            % velocity_grid: grid with velocity of the grid


            % Calculate the velocity of the grid using the distribution densities and the density
            velocity_grid(:, :, :, 1) = N_Grid(:,:,:,1) - N_Grid(:,:,:,2) + N_Grid(:,:,:,7) - N_Grid(:,:,:,8) ...
                                        + N_Grid(:,:,:,9) - N_Grid(:,:,:,10) + N_Grid(:,:,:,13) - N_Grid(:,:,:,14) + N_Grid(:,:,:,15) - N_Grid(:,:,:,16);  % x-velocity

            velocity_grid(:, :, :, 2) = N_Grid(:,:,:,3) - N_Grid(:,:,:,4) + N_Grid(:,:,:,7) - N_Grid(:,:,:,8)...
                                        + N_Grid(:,:,:,11) - N_Grid(:,:,:,12) - N_Grid(:,:,:,13) + N_Grid(:,:,:,14) + N_Grid(:,:,:,17) - N_Grid(:,:,:,18);  % y-velocity
            
            velocity_grid(:, :, :, 3) = N_Grid(:,:,:,5) - N_Grid(:,:,:,6) + N_Grid(:,:,:,9) - N_Grid(:,:,:,10)...
                                        + N_Grid(:,:,:,11) - N_Grid(:,:,:,12) - N_Grid(:,:,:,15) + N_Grid(:,:,:,16) - N_Grid(:,:,:,17) + N_Grid(:,:,:,18);  % z-velocity
            
            % divide the velocity by the density to get the velocity of each cell
            velocity_grid(:,:,:,:) = velocity_grid(:,:,:,:) ./ density_grid();

            % set the velocity to 0 where there is geometry
            velocity_grid(:,:,:,:) = velocity_grid(:,:,:,:) .* ~bb_mask;  % ToDo: maybe there is a more efficient way?
            velocity_grid(isnan(velocity_grid)) = 0;  
            %disp("desnity grid 2:")
            %density_grid(:,1,:)
            %disp("calculate velocity")  
            %velocity_grid(:,1,:,2)

        end

        function [N_grid] = calculate_equilibrium_and_update(density_grid, velocity_grid, divs, N_grid, tau)
            % calculate_equilibrium: calculates the equilibrium distribution density of the grid
            % inputs------------------------------------------
            % density_grid: grid with density of the grid
            % velocity_grid: grid with velocity of the grid
            % returns-----------------------------------------
            % equilibrium_grid: grid with equilibrium distribution density of the grid

        
            % todo: maybe this should be done in 2D as well? Also if memory is an issue, only precalculate scalar values
            % to minimize GPU usage: divide the density by the weighing factors beforehand
            density_grid_div_36 = density_grid ./ 36;

            % Calculate the equilibrium distribution densities for each direction (the part after the big space)
            % then use it to update the N_grid in place
            N_grid(:,:,:,1) = N_grid(:,:,:,1) - (1/tau).*(N_grid(:,:,:,1) -         (density_grid_div_36 .*  (2 + 6.*velocity_grid(:,:,:,1) + 9.*velocity_grid(:,:,:,1).^2 - 3.*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,2) = N_grid(:,:,:,2) - (1/tau).*(N_grid(:,:,:,2) -         (density_grid_div_36 .*  (2 - 6.*velocity_grid(:,:,:,1) + 9.*velocity_grid(:,:,:,1).^2 - 3.*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,3) = N_grid(:,:,:,3) - (1/tau).*(N_grid(:,:,:,3) -         (density_grid_div_36 .*  (2 + 6.*velocity_grid(:,:,:,2) + 9.*velocity_grid(:,:,:,2).^2 - 3.*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,4) = N_grid(:,:,:,4) - (1/tau).*(N_grid(:,:,:,4) -         (density_grid_div_36 .*  (2 - 6.*velocity_grid(:,:,:,2) + 9.*velocity_grid(:,:,:,2).^2 - 3.*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,5) = N_grid(:,:,:,5) - (1/tau).*(N_grid(:,:,:,5) -         (density_grid_div_36 .*  (2 + 6.*velocity_grid(:,:,:,3) + 9.*velocity_grid(:,:,:,3).^2 - 3.*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,6) = N_grid(:,:,:,6) - (1/tau).*(N_grid(:,:,:,6) -         (density_grid_div_36 .*  (2 - 6.*velocity_grid(:,:,:,3) + 9.*velocity_grid(:,:,:,3).^2 - 3.*dot(velocity_grid, velocity_grid, 4))) );

            
            N_grid(:,:,:,7)  = N_grid(:,:,:,7)  - (1/tau).* (N_grid(:,:,:,7)  -     (density_grid_div_36 .* (1 + 3.*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,2)) + divs(2).*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,2)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,8)  = N_grid(:,:,:,8)  - (1/tau).* (N_grid(:,:,:,8)  -     (density_grid_div_36 .* (1 - 3.*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,2)) + divs(2).*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,2)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,9)  = N_grid(:,:,:,9)  - (1/tau).* (N_grid(:,:,:,9)  -     (density_grid_div_36 .* (1 + 3.*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,3)) + divs(2).*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,10) = N_grid(:,:,:,10) - (1/tau).* (N_grid(:,:,:,10) -     (density_grid_div_36 .* (1 - 3.*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,3)) + divs(2).*(velocity_grid(:,:,:,1)  + velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,11) = N_grid(:,:,:,11) - (1/tau).* (N_grid(:,:,:,11) -     (density_grid_div_36 .* (1 + 3.*(velocity_grid(:,:,:,2)  + velocity_grid(:,:,:,3)) + divs(2).*(velocity_grid(:,:,:,2)  + velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,12) = N_grid(:,:,:,12) - (1/tau).* (N_grid(:,:,:,12) -     (density_grid_div_36 .* (1 - 3.*(velocity_grid(:,:,:,2)  + velocity_grid(:,:,:,3)) + divs(2).*(velocity_grid(:,:,:,2)  + velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,13) = N_grid(:,:,:,13) - (1/tau).* (N_grid(:,:,:,13) -     (density_grid_div_36 .* (1 + 3.*(velocity_grid(:,:,:,1)  - velocity_grid(:,:,:,2)) + divs(2).*(velocity_grid(:,:,:,1)  - velocity_grid(:,:,:,2)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,14) = N_grid(:,:,:,14) - (1/tau).* (N_grid(:,:,:,14) -     (density_grid_div_36 .* (1 + 3.*(-velocity_grid(:,:,:,1) + velocity_grid(:,:,:,2)) + divs(2).*(-velocity_grid(:,:,:,1) + velocity_grid(:,:,:,2)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,15) = N_grid(:,:,:,15) - (1/tau).* (N_grid(:,:,:,15) -     (density_grid_div_36 .* (1 + 3.*(velocity_grid(:,:,:,1)  - velocity_grid(:,:,:,3)) + divs(2).*(velocity_grid(:,:,:,1)  - velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,16) = N_grid(:,:,:,16) - (1/tau).* (N_grid(:,:,:,16) -     (density_grid_div_36 .* (1 + 3.*(-velocity_grid(:,:,:,1) + velocity_grid(:,:,:,3)) + divs(2).*(-velocity_grid(:,:,:,1) + velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,17) = N_grid(:,:,:,17) - (1/tau).* (N_grid(:,:,:,17) -     (density_grid_div_36 .* (1 + 3.*(velocity_grid(:,:,:,2)  - velocity_grid(:,:,:,3)) + divs(2).*(velocity_grid(:,:,:,2)  - velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,18) = N_grid(:,:,:,18) - (1/tau).* (N_grid(:,:,:,18) -     (density_grid_div_36 .* (1 + 3.*(-velocity_grid(:,:,:,2) + velocity_grid(:,:,:,3)) + divs(2).*(-velocity_grid(:,:,:,2) + velocity_grid(:,:,:,3)).^2 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );
            N_grid(:,:,:,19) = N_grid(:,:,:,19) - (1/tau).* (N_grid(:,:,:,19) -     (density_grid ./ 3 .*  (1 - divs(1).*dot(velocity_grid, velocity_grid, 4))) );

            % ToDo: if memory is an issue, only precalculate scalar values
        end

        function [N_grid] = collision_update(N_grid, N_eq_grid, tau)
            % collision_update: updates the distribution densities in the grid according to the D3 model
            % inputs------------------------------------------
            % N_grid: grid with distribution density
            % N_eq_grid: grid with equilibrium distribution density
            % tau: relaxation parameter
            % returns-----------------------------------------
            % N_grid: updated grid with distribution density

            % Collision update step using the relaxation parameter tau
            N_grid = N_grid - (1/tau) .* (N_grid - N_eq_grid);
        end

        function myDrawnowGPU(t, Grid, simulation_space_size)
        disp("plotting")
        % myDrawnow: function to plot the simulation
        % inputs:------------------------------------------
        % t: the chosen timesteps
        % Grid: grid with distribution density and other masks, grids of the same size


        % Parameters of the grid

        lines = simulation_space_size(1); % number of lines in the grid
        cols = simulation_space_size(2); % number of columns in the grid
        depth = simulation_space_size(3); % number of depth in the grid
        % [grid_y, grid_x , grid_z] = meshgrid(1:cols,1:lines, 1:depth);
        [grid_x, grid_y , grid_z] = meshgrid(1:cols,1:lines, 1:depth);
        
        % Quiver we have used before:
        % quiver3(grid_x, grid_y, grid_z, Grid(:,:,:,22), Grid(:,:,:,21),Grid(:,:,:,23)); % plot the velocity vectors in 3D, but with black arrows);
        
        height_scalingfactor = 10;
        depth_scalingfactor = 10;
        [startX, startY , startZ] = meshgrid(1,linspace(1,lines,depth_scalingfactor),linspace(1,depth,height_scalingfactor));

        dim3 = streamline(Grid(:,:,:,22),Grid(:,:,:,21),Grid(:,:,:,23), startX, startY,startZ);
        view(3)
        hold on
    
        % todo: 
        Grid(1,:,:,20) = 0; % remove the walls from the bounce back mask to plot only the airfoil
        Grid(end,:,:,20) = 0;
        Grid(:,:,1,20) = 0;
        Grid(:,:,end,20) = 0;
        
        [i, j, k] = ind2sub(size(Grid(:,:,:,20)), find(Grid(:,:,:,20)));

        
        % Plot the bb_mask 3D scatter 
        % todo: needs to be changed to just be the airfoil
        % scatter3(j, i, k, 20, 'filled'); % (X=cols, Y=lines, Z=depth)
        
        set(gca,'DataAspectRatio',[1 1 1])
        % abs_velocity = sqrt(Grid(:,:,:,21).^2 + Grid(:,:,:,22).^2 + Grid(:,:,:,23).^2);  
        %abs_velocity = abs_velocity ./ ~ bb_mask;

        i_double = double(gather(i));
        j_double = double(gather(j));
        k_double = double(gather(k));

        wing = alphaShape(j_double ,i_double ,k_double); % create an alpha shape from the bounce back mask
        plot(wing, 'FaceColor','#5c5f77', 'EdgeColor', "#4c4f69");

        % Plot the velocity distribution as a countour plot
        %contour3(grid_x, grid_y, grid_z, abs_velocity, 100, 'edgecolor','none');
        
        xlabel('x-position')
        ylabel('y-position')
        zlabel('z-position')
        title('Velocity distribution in flow channel (Timesteps now: ' + string(t) + ')')
        
        figure
        quiver3(grid_x, grid_y, grid_z, Grid(:,:,:,25), Grid(:,:,:,26),Grid(:,:,:,27))

        end
    end
end

