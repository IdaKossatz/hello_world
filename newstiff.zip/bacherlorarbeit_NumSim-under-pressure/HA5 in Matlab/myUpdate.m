function [Grid, parameters] = myUpdate(Grid, parameters, dt)
    % Update rules for the simulation
    % inputs:------------------------------------------
    % Grid: grid with distribution density
    % parameters: struct with parameters needed for the simulation
    % dt: plot intervall (one cpu) or communication intervall (multicore)
    % returns:------------------------------------------
    % Grid: grid with distribution density
    % parameters: struct with parameters needed for the simulation

    % Parameters:-------------------------------------------------------------------------------------------------------
    % Simulation parameters
    bb_mask = Grid(:,:,10); % get the bb_mask
    open_end_mask = Grid(:,:,14); % get the open_end_mask
    open_end_mask = logical(open_end_mask); % make sure the open_end_mask is logical
    N_grid = Grid(:,:,1:9); % remove the last layers of the grid that dont contain distribution densities
    velocity_grid = Grid(:,:,12:13); % get the velocity grid
    
    % Timeloop that moves and updates the distribution densities for a given time step dt ------------------------------
    % is nested with the loop in the LBM function to allow parallelization during multicore simulation
    for i = 1:dt
        % II. Streaming Step
        N_grid = update.move_distribution_density(N_grid, parameters.inlet_speed_grid, parameters.one_over_1_minus_inspeed, bb_mask, open_end_mask); % works

        % III. Calculate density and velocity
        density_grid = update.calculate_density(N_grid); % works
        
        velocity_grid = update.calculate_velocity(N_grid, density_grid, bb_mask, velocity_grid); % works

        % IV. Calculate equilibrium distribution density
        N_eq_grid = update.calculate_equilibrium(density_grid, velocity_grid); % works

        % V. Collision: Calculating of the distribution density after a collision
        N_grid = update.collision_update(N_grid, N_eq_grid, parameters.xi);
    end

    % Add the new and also the previously cut layers back to the grid---------------------------------------------------
    N_grid(:,:,10) = bb_mask; % add the bb_mask
    N_grid(:,:,11) = open_end_mask; % add the open_end_mask
    N_grid(:,:,12:13) = velocity_grid; % add the velocity grid
    N_grid(:,:,14) = open_end_mask; % add the open_end_mask
    Grid = N_grid; % just for the sake of it, the grid is already updated
    
end