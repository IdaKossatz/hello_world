classdef update
    methods(Static)
        function [N_grid] =  move_distribution_density(N_grid, inlet_speed_grid, one_over_1_minus_inspeed, bb_mask, open_end_mask)
            % move_distribution_density(.): moves the distribution densities in the grid
            % inputs:------------------------------------------
            % N_grid: grid with distribution density
            % inlet_speed: speed of the inlet
            % one_over_1_minus_inspeed: 1/(1-inlet_speed) grid for inflow cells
            % bb_mask: mask for the geometry and wall
            % open_end_mask: mask for the open end condition
            % returns:------------------------------------------
            % N_grid: grid with distribution density

            
            % Moving the distribution densities in the grid to the next node--------------------------------------------

            % Shift for loop was unrolled as advised by Krüger P.69
            N_grid(:, :, 1) = circshift(N_grid(:, :, 1), [0 1]); % N_1
            N_grid(:, :, 2) = circshift(N_grid(:, :, 2), [1 0]); % N_2
            N_grid(:, :, 3) = circshift(N_grid(:, :, 3), [0 -1]); % N_3
            N_grid(:, :, 4) = circshift(N_grid(:, :, 4), [-1 0]); % N_4
            N_grid(:, :, 5) = circshift(N_grid(:, :, 5), [1 1]); % N_5
            N_grid(:, :, 6) = circshift(N_grid(:, :, 6), [1 -1]); % N_6
            N_grid(:, :, 7) = circshift(N_grid(:, :, 7), [-1 -1]); % N_7
            N_grid(:, :, 8) = circshift(N_grid(:, :, 8), [-1 1]); % N_8
            
            % Implementation of the do-nothing-boundary-condition at the right boundary---------------------------------
            % Save the distribution densities that are in the open end so they can be accessed using the open_end_mask
            % logical array
            N_3 = N_grid(:, :, 3);
            N_7 = N_grid(:, :, 7);
            N_6 = N_grid(:, :, 6);
            
            % reflect outflowing distribution densities at the open end back into the grid where open_end_mask is true
            N_3(open_end_mask) = N_3(circshift(open_end_mask, [0 -1]));    % N3
            N_7(open_end_mask) = N_7(circshift(open_end_mask, [-1 -1]));   % N7
            N_6(open_end_mask) = N_6(circshift(open_end_mask, [1 -1]));    % N6
            
            % Re assign the distribution densities to the grid
            N_grid(:, :, 3) = N_3;
            N_grid(:, :, 7) = N_7;
            N_grid(:, :, 6) = N_6; 
            
            % Implementation for the Bounce-Back-Condition (wall adhesion):---------------------------------------------
            % Used at the geometry (includes the upper and lower channel walls).
            % geometry_overflow catches the distribution densities that would "flow into" the geometry,
            % in order to reflect them
            
            % Saving the distribution densities that would flow into the geometry
            geometry_overflow = N_grid .* bb_mask;
            
            % Reverse the flow direction of all distribution densities that have flown in to the geometry, and flow them 
            % back out the way they came in, implementing the wall adhesion boundary condition
            % Was rewritten explicitly as advised by Krüger P.69
            N_grid(:, :, 1) = N_grid(:, :, 1) + circshift(geometry_overflow(:, :, 3), [0 1]); % N_1
            N_grid(:, :, 2) = N_grid(:, :, 2) + circshift(geometry_overflow(:, :, 4), [1 0]); % N_2
            N_grid(:, :, 3) = N_grid(:, :, 3) + circshift(geometry_overflow(:, :, 1), [0 -1]); % N_3
            N_grid(:, :, 4) = N_grid(:, :, 4) + circshift(geometry_overflow(:, :, 2), [-1 0]); % N_4
            N_grid(:, :, 5) = N_grid(:, :, 5) + circshift(geometry_overflow(:, :, 7), [1 1]); % N_5
            N_grid(:, :, 6) = N_grid(:, :, 6) + circshift(geometry_overflow(:, :, 8), [1 -1]); % N_6
            N_grid(:, :, 7) = N_grid(:, :, 7) + circshift(geometry_overflow(:, :, 5), [-1 -1]); % N_7
            N_grid(:, :, 8) = N_grid(:, :, 8) + circshift(geometry_overflow(:, :, 6), [-1 1]); % N_8

            % Calculate the density of the first column in the grid-----------------------------------------------------
            % to calculate the new distribution densities after the inflow
            density_grid_first_col = one_over_1_minus_inspeed .* (N_grid(:, 1, 2) + N_grid(:, 1, 4) + N_grid(:, 1, 9) ...
                + 2 * (N_grid(:, 1, 3) + N_grid(:, 1, 6) + N_grid(:, 1, 7)));  
            
            % Apply the new inflow distribution densities to the left boundary of the grid
            N_grid(:, 1, 1) = N_grid(:, 1, 3) + 2/3 * density_grid_first_col .* inlet_speed_grid; % N_1
            N_grid(:, 1, 5) = 1/6 * density_grid_first_col .* inlet_speed_grid + N_grid(:, 1, 7) - N_grid(:, 1, 2)/2 + N_grid(:, 1, 4)/2; % N_5
            N_grid(:, 1, 8) = 1/6 * density_grid_first_col .* inlet_speed_grid + N_grid(:, 1, 6) - N_grid(:, 1, 4)/2 + N_grid(:, 1, 2)/2; % N_8
            
            % Where bb_mask is true, the distribution densities of the nodes are set to 0 because it is geometry 
            N_grid = N_grid .* ~bb_mask;
        end

        function [density_grid] = calculate_density(N_grid)
            % calculate_density(.): calculates the density of each grid point
            % inputs:------------------------------------------
            % N_grid: grid with distribution density
            % returns:------------------------------------------
            % density_grid: density of each grid point

            % length(size(N_grid)) allows to sum over the last dimension, regardless of the number of dimensions
            density_grid = sum(N_grid, (length(size(N_grid))));
        
        end

        function [velocity_grid] = calculate_velocity(N_grid, density_grid, bb_mask, velocity_grid)
            % calculate_velocity(.): calculates the velocity of each grid point in 2 dimensions
            % inputs:------------------------------------------
            % N_grid: grid with distribution density
            % density_grid: density of each grid point
            % bb_mask: mask for the geometry and wall
            % velocity_grid: velocity of each grid point in 2 dimensions
            % returns:------------------------------------------
            % velocity_grid: velocity of each grid point in 2 dimensions

            % Calculate momentum density (massflux density) at each grid point
            velocity_grid(:, :, 1) = N_grid(:, :, 1) - N_grid(:, :, 3) + N_grid(:, :, 5) - N_grid(:, :, 6) - N_grid(:, :, 7) + N_grid(:, :, 8);
            velocity_grid(:, :, 2) = N_grid(:, :, 2) - N_grid(:, :, 4) + N_grid(:, :, 5) + N_grid(:, :, 6) - N_grid(:, :, 7) - N_grid(:, :, 8);
            
            % Divide the momentum density by the density to get the velocity of each grid point
            velocity_grid(:,:,:) = velocity_grid(:,:,:) ./ density_grid();

            % Set the velocity of the nodes that are in the geometry to 0 (e.g. when density is 0, velocity is NaN)
            velocity_grid(:,:,:) = velocity_grid(:,:,:) .* ~bb_mask;
            velocity_grid(isnan(velocity_grid)) = 0;
        
        end

        function [N_eq_grid] = calculate_equilibrium(density_grid, velocity_grid)
            % calculate_equilibrium(.): calculates the BGK equilibrium distribution density of each grid point
            % inputs:------------------------------------------
            % density_grid: density of each grid point
            % velocity_grid: velocity of each grid point
            % returns:------------------------------------------
            % N_eq_grid: equilibrium distribution density of each grid point
            
            N_eq_grid(:,:,1) = density_grid ./ 18 .* (2 + 6.*velocity_grid(:,:,1) + 9.*velocity_grid(:,:,1).^2 - 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_1
            N_eq_grid(:,:,2) = density_grid ./ 18 .* (2 + 6.*velocity_grid(:,:,2) + 9.*velocity_grid(:,:,2).^2 - 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_2
            N_eq_grid(:,:,3) = density_grid ./ 18 .* (2 - 6.*velocity_grid(:,:,1) + 9.*velocity_grid(:,:,1).^2 - 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_3
            N_eq_grid(:,:,4) = density_grid ./ 18 .* (2 - 6.*velocity_grid(:,:,2) + 9.*velocity_grid(:,:,2).^2 - 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_4
            N_eq_grid(:,:,5) = density_grid ./ 36 .* (1 + 3.*(velocity_grid(:,:,1) + velocity_grid(:,:,2)) + 9.*velocity_grid(:,:,1).*velocity_grid(:,:,2) + 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_5
            N_eq_grid(:,:,6) = density_grid ./ 36 .* (1 - 3.*(velocity_grid(:,:,1) - velocity_grid(:,:,2)) - 9.*velocity_grid(:,:,1).*velocity_grid(:,:,2) + 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_6
            N_eq_grid(:,:,7) = density_grid ./ 36 .* (1 - 3.*(velocity_grid(:,:,1) + velocity_grid(:,:,2)) + 9.*velocity_grid(:,:,1).*velocity_grid(:,:,2) + 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_7
            N_eq_grid(:,:,8) = density_grid ./ 36 .* (1 + 3.*(velocity_grid(:,:,1) - velocity_grid(:,:,2)) - 9.*velocity_grid(:,:,1).*velocity_grid(:,:,2) + 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_8

            N_eq_grid(:,:,9) = 2.*density_grid ./ 9 .* (2 - 3.*(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2)); % N_9
        end

        function [N_grid] = collision_update(N_grid, N_eq_grid, xi)
            % collision_update(.): calculates the distribution density after a collision
            % inputs:------------------------------------------
            % N_grid: grid with distribution density
            % N_eq_grid: equilibrium distribution density of each grid point
            % xi: relaxation parameter
            % returns:------------------------------------------
            % N_grid: grid with distribution density after a collision

            N_grid = N_grid - (1/(xi)) .* (N_grid - N_eq_grid);
        end
        
    end
end