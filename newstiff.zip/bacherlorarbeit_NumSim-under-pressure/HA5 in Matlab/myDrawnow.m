function [parameters] = myDrawnow(parameters, t, Grid)
    % myDrawnow: function to plot the simulation
    % inputs:------------------------------------------
    % parameters: struct with parameters needed for the simulation
    % t: current timestep
    % Grid: grid with distribution density and other masks, grids of the same size
    % returns:------------------------------------------
    % parameters: struct with parameters needed for the simulation
    
    % If the plot object does not exist, create it---------------------------------------------------
    if parameters.plot == 0
        % Parameters of the grid
        bb_mask = Grid(:,:,10); % get the bb_mask from the grid
        lines = size(bb_mask, 1); % number of lines in the grid
        cols = size(bb_mask, 2); % number of columns in the grid

        [X, Y] = meshgrid(0:cols-1, 0:lines-1);  % get coordinates for the grid

        % Parameters for the quiver plot
        downsample_factor = fix(cols/20);  % downsample factor
        X_d = X(1:downsample_factor:end, 1:downsample_factor:end);  % downsample the grid
        Y_d = Y(1:downsample_factor:end, 1:downsample_factor:end);  % downsample the grid
        
        % Save the needed parameters in the parameters struct
        parameters.contour_grid_X = X; % save the grid for the contour plot
        parameters.contour_grid_Y = Y; % save the grid for the contour plot
        parameters.quiver_grid_X = X_d;
        parameters.quiver_grid_Y = Y_d; % save the grid for the quiver plot
        parameters.downsample_factor = downsample_factor;

        % set the plot object to 1, to stop the myDrawnow function creating the same constant data on each call
        parameters.plot = 1;

    % If the plot object does exist update the plot data---------------------------------------------------
    else
        % Parameters of the grid
        bb_mask = Grid(:,:,10); % get the bb_mask 
        velocity_grid = Grid(:,:,12:13);  % get the velocity grid
        
        % Calculate absolute velocity of the velocity grid
        abs_velocity = sqrt(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2);  
        abs_velocity = abs_velocity ./ ~ bb_mask;

        % Downsample the velocity grid
        d_velocity_grid = velocity_grid(1:parameters.downsample_factor:end, 1:parameters.downsample_factor:end, :);

        % Plot the velocity distribution as a countour plot
        contourf(parameters.contour_grid_X, parameters.contour_grid_Y, abs_velocity, 100, 'edgecolor','none');
        % Define plot parameters and labels
        set(gca, 'YDir','reverse') % mirror the y-axis
        colormap('jet') 
        colorbar()
        xlabel('x-position')
        ylabel('y-position')
        title('Velocity distribution in flow channel (Timesteps now: ' + string(t) + ')')

        
        % Plot the velocity vectors as a quiver plot
        hold on
        quiver(parameters.quiver_grid_X, parameters.quiver_grid_Y, d_velocity_grid(:,:,1), d_velocity_grid(:,:,2), 0.5, "black");
        hold off
        
        drawnow limitrate % needed for the animation when doing the simulation single core
    end
end