% Defines the class multi with static methods for parallel processing
classdef multi
    methods(Static)
        function Grid_local = spmd_nonperiodic_add_space(Grid_local, overlap)
            % spmd_nonperiodic_add_space(.): adds extra space for overlap (must be called inside spmd block!)
            % inputs:------------------------------------------
            % Grid_local: local grid data
            % overlap: number of overlapping nodes
            % returns:------------------------------------------
            % Grid_local: local grid data with extra space for overlap

            
            cpu = spmdIndex; % Worker (matlab instance) id.
            numcpu = spmdSize; % total number of workers

            [nx,~,nc] = size(Grid_local);
            
            % setup: extra overlapping nodes
            if cpu == 1 % most left cpu
                Grid_local = [ Grid_local , zeros(nx,overlap,nc) ]; 

            elseif cpu == numcpu % most right cpu
                Grid_local = [ zeros(nx,overlap,nc) , Grid_local ];

            else % cpu in between
                Grid_local = [ zeros(nx,overlap,nc) , Grid_local , zeros(nx,overlap,nc) ];

            end
            
        end

        function Grid_local = spmd_nonperiodic_rem_space(Grid_local, overlap)
            % spmd_nonperiodic_rem_space(.): removes extra space for overlap (must be called inside spmd block!)
            % inputs:------------------------------------------
            % Grid_local: local grid data
            % overlap: number of overlapping nodes
            % returns:------------------------------------------
            % Grid_local: local grid data without extra space for overlap
            
            cpu = spmdIndex;
            numcpu = spmdSize;
            
            % remove extra space
            if cpu == 1 % most left cpu
                Grid_local = Grid_local(:,1:end-overlap,:);

            elseif cpu == numcpu % most right cpu
                Grid_local = Grid_local(:,overlap+1:end,:);

            else % cpu in between
                Grid_local = Grid_local(:,overlap+1:end-overlap,:);

            end
            
        end   
        
        function Grid_local = spmd_nonperiodic_update(Grid_local, parameters, dt, overlap)
            % spmd_nonperiodic_update(.): interchanges data with neighbours and update local grid (must be called inside spmd block!)
            % inputs:------------------------------------------
            % Grid_local: local grid data
            % p: parameters for the update rule
            % dt: time step
            % overlap: number of overlapping nodes
            % returns:------------------------------------------
            % Grid_local: updated local grid data
            
            cpu = spmdIndex;
            numcpu = spmdSize;
            
            % Communication step
            if cpu == 1 % most left cpu
                G_right_inner = Grid_local(:,end-2*overlap+1:end-overlap,:);
                G_right_outer = spmdSendReceive(cpu+1,cpu+1,G_right_inner);
                Grid_local(:,end-overlap+1:end,:) = G_right_outer;

            elseif cpu == numcpu % most right cpu
                G_left_inner = Grid_local(:,overlap+1:2*overlap,:);
                G_left_outer = spmdSendReceive(cpu-1,cpu-1,G_left_inner);
                Grid_local(:,1:overlap,:) = G_left_outer;
                
            else % cpu in between
                G_left_inner = Grid_local(:,overlap+1:2*overlap,:);
                G_right_inner = Grid_local(:,end-2*overlap+1:end-overlap,:);

                if mod(cpu,2) == 0
                    G_left_outer = spmdSendReceive(cpu-1,cpu-1,G_left_inner);
                    G_right_outer = spmdSendReceive(cpu+1,cpu+1,G_right_inner);
                else
                    G_right_outer = spmdSendReceive(cpu+1,cpu+1,G_right_inner);
                    G_left_outer = spmdSendReceive(cpu-1,cpu-1,G_left_inner);
                end

                Grid_local(:,1:overlap,:) = G_left_outer;
                Grid_local(:,end-overlap+1:end,:) = G_right_outer;
            end
            
            % Update the local grids
            Grid_local = myUpdate(Grid_local,parameters,dt);
            
        end

        function parforWaitbar(waitbarHandle,iterations)
            % parforWaitbar(.): function to update the waitbar in a parfor loop
            % inputs:------------------------------------------
            % waitbarHandle: handle to the waitbar
            % iterations: number of iterations
        
            persistent count h N
            
            if nargin == 2
                % Initialize
                count = 0;
                h = waitbarHandle;
                N = iterations;

            else
                % Update the waitbar
                % Check whether the handle is a reference to a deleted object
                if isvalid(h)
                    count = count + 1;
                    waitbar(count / N,h);
                end

            end
        end

    end
end