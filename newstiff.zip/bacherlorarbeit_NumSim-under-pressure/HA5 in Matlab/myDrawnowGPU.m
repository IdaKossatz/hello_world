function myDrawnowGPU(t, Grid)
    % myDrawnow: function to plot the simulation
    % inputs:------------------------------------------
    % t: the chosen timesteps
    % Grid: grid with distribution density and other masks, grids of the same size


    % Parameters of the grid
    bb_mask = Grid(:,:,10); % get the bb_mask from the grid
    velocity_grid = Grid(:,:,12:13);  % get the velocity grid

    lines = size(bb_mask, 1); % number of lines in the grid
    cols = size(bb_mask, 2); % number of columns in the grid

    [contour_grid_X, contour_grid_Y] = meshgrid(0:cols-1, 0:lines-1);  % get coordinates for the contour plot
    
    % Parameters for the quiver plot
    downsample_factor = fix(cols/20);  % downsample factor, smaller values = more arrows
    % downsample the grid for the quiver plot
    quiver_grid_X = contour_grid_X(1:downsample_factor:end, 1:downsample_factor:end);
    quiver_grid_Y = contour_grid_Y(1:downsample_factor:end, 1:downsample_factor:end);
    
    % Calculate absolute velocity of the velocity grid
    abs_velocity = sqrt(velocity_grid(:,:,1).^2 + velocity_grid(:,:,2).^2);  
    abs_velocity = abs_velocity ./ ~ bb_mask;

    % Downsample the velocity grid
    d_velocity_grid = velocity_grid(1:downsample_factor:end, 1:downsample_factor:end, :);

    % Plot the velocity distribution as a countour plot
    contourf(contour_grid_X, contour_grid_Y, abs_velocity, 100, 'edgecolor','none');

    % Define plot parameters and labels
    set(gca, 'YDir','reverse') % mirror the y-axis
    colormap('jet') 
    colorbar()
    xlabel('x-position')
    ylabel('y-position')
    title('Velocity distribution in flow channel (Timesteps now: ' + string(t) + ')')
    
    % Plot the velocity vectors as a quiver plot
    hold on
    quiver(quiver_grid_X, quiver_grid_Y, d_velocity_grid(:,:,1), d_velocity_grid(:,:,2), 0.5, "black");
    hold off

end