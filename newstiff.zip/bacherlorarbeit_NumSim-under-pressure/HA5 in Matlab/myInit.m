function [Grid, parameters] = myInit(lines_cols, xi, inlet_speed)
    % myInit: initializes the grid and parameters for the simulation
    % inputs------------------------------------------
    % lines_cols: size of the grid in a 2x1 array
    % returns-----------------------------------------
    % Grid: grid with distribution density and other grid masks and velocity grids of the same size
    % parameters: struct with parameters needed for the simulation

    % Parameters:-------------------------------------------------------------------------------------------------------
    
    inlet_speed_grid = ones(lines_cols(1), 1) * inlet_speed;
    inlet_speed_grid(1:2) = 0;  % disable flow in and right next to wall
    inlet_speed_grid(end-1:end) = 0;
    parameters.inlet_speed_grid = inlet_speed_grid;

    parameters.one_over_1_minus_inspeed = 1 ./ (1 - inlet_speed_grid);  % define here to avoid repeated devision in the loop
    parameters.xi = xi;

    % Create wing geometry as bounce-back mask (bb_mask) using Lars' function % ToDo: may need changes.
    angle_of_attack = 20; % Angle of attack
    
    bb_mask = initial.make_domain(lines_cols(1), lines_cols(2), angle_of_attack);
    bb_mask(1, 1:end) = true;   % define upper wall of the flow channel
    bb_mask(end, 1:end) = true; % define lower wall of the flow channel
    
    % I. Initalization--------------------------------------------------------------------------------------------------
    % Initializing the grid using the initializer function
    Grid = initial.Initializer(bb_mask, inlet_speed_grid, lines_cols(1), lines_cols(2)); 
    %-------------------------------------------------------------------------------------------------------------------
    
    % Append bb_mask to the Grid so it can be parallelized
    Grid(:,:,10) = bb_mask;  
    
    % Create an open end map for the outflow/drain condition where the last column is set to 1(simulate open end) 
    % and append it to the Grid so it can be parallelized 
    % Grid(:,:,11) = open_end_mask;
    open_end_mask = zeros(lines_cols(1), lines_cols(2), 1);
    open_end_mask(:, end) = 1; % set last row to 1

    % Create a placeholder for the velocity grid and append it to the Grid so it can be parallelized
    Grid(:,:,12:13) = zeros(lines_cols(1), lines_cols(2), 2); 
    Grid(:,:,14) = open_end_mask;
end