% used for launcing user defined versions of the LBM function
clear;
close all   
% Domain properties ---------------------------------------------------------
lines = 100; %y
cols = 200;  %x
depth = 16; %z
Dims = 3;  % Dimensions
tend = 400;

% Fluid properties ----------------------------------------------------------
% Note: cs does not affect 2D simulations and is always set to 1/sqrt(3) for 2D
inlet_speed = 0.1;   % Inlet flowspeed
tau = 2/3;  % Relaxation parameter, refine later
cs = 1/sqrt(3);  % speed of sound in the lattice (1/sqrt(3) * delta_x^2 / delta_t^2)

% Pressure boundary condition, set one variable to 0 for velocity boundary condition 
% optimal values for flow similiar to velocity boundary condition are pressure_in = 1/2 and pressure_out = 1/4
% (also: pressure = 1/3 => density of 1)
pressure_in = 0;  
pressure_out = 1/4;  

% Collision model ----------------------------------------------------------
collision_model = 'BGK';  % Collision model, can be 'BGK' or 'TRT'

% Compute settings ----------------------------------------------------------
% Note: numcpu = 0 for GPU simulations, numcpu > 0 for CPU
dt = 1;
numcpu = 0;
graphics = 1;


LBM(lines, cols, depth, numcpu, dt, tend, graphics, Dims, tau, cs, inlet_speed, pressure_in, pressure_out, collision_model);

% can be used in order to use gputimeit(L) in console
% L = @() LBM(lines, cols, depth, numcpu, dt, tend, graphics, Dims, tau, cs, inlet_speed);


