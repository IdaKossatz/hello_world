function [Grid, xi, inlet_speed_grid, one_over_1_minus_inspeed, open_end_mask] = myInitGPU(lines_cols, xi, inlet_speed)
    % myInit: initializes the grid and parameters for the simulation as gpuArrays
    % inputs------------------------------------------
    % size: size of the grid 1x2 array with number of lines and columns
    % returns-----------------------------------------
    % Grid: grid with distribution density and other grid masks and velocity grids of the same size
    % xi: relaxation parameter
    % inlet_speed_grid: grid with inlet speed from the left (0 means no inlet)
    % one_over_1_minus_inspeed: grid with 1/(1-inlet_speed) for each cell
    % open_end_mask: grid with open end mask for the open end condition


    inlet_speed_grid = gpuArray(ones(lines_cols(1),1) * inlet_speed); 
    inlet_speed_grid(1:2) = 0;  % disable flow in and right next to wall
    inlet_speed_grid(end-1:end)= 0;

    one_over_1_minus_inspeed = 1 ./ (1 - inlet_speed_grid);  % define here to avoid repeated devision in the loop
    
    % Create wing geometry as bounce-back mask (bb_mask) using Lars' function % ToDo: may need changes.
    angle_of_attack = 20; % Angle of attack
    
    bb_mask = gpuArray(initial.make_domain(lines_cols(1), lines_cols(2), angle_of_attack));
    bb_mask(1, 1:end) = true;   % define upper wall of the flow channel
    bb_mask(end, 1:end) = true; % define lower wall of the flow channel
    
    % I. Initalization--------------------------------------------------------------------------------------------------
    % Initializing the grid using the initializer function
    Grid = gpuArray(initial.InitializerGPU(bb_mask, inlet_speed_grid, lines_cols(1), lines_cols(2))); 
    %-------------------------------------------------------------------------------------------------------------------
    
    % Append bb_mask to the Grid so it can be parallelized
    Grid(:,:,10) = bb_mask;  
    
    % Create an open end map for the outflow/drain condition where the last column is set to 1(simulate open end) 
    % and append it to the Grid so it can be parallelized 
    % Grid(:,:,11) = open_end_mask;
    open_end_mask = gpuArray(zeros(lines_cols(1), lines_cols(2), 1));
    open_end_mask(:, end) = 1; % set last row to 1
    open_end_mask = logical(open_end_mask);
    
end