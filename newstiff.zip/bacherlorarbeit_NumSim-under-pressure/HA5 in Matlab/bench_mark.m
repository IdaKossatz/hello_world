clc

% benchmark the performance of the simulation and create nice plots

% grid sizes
% cell_number = [10^5 10/3*10^5 20/3*10^5 10^6 10/3*10^6 20/3*10^6 10^7 10/3*10^7 20/3*10^7 10^8 10/3*10^8 20/3*10^8]
cell_number = [10^5 10/3*10^5 20/3*10^5 10^6 10/3*10^6 20/3*10^6 10^7 10/3*10^7 20/3*10^7];
% cell_number = [10^5 10/3*10^5 20/3*10^5];

max_single_core_cells = 10^7;
grid_sizes = cell_number./9; % divide by 9 because the grid is 9 times bigger than the number of cells 
grid_sizes = round(grid_sizes.^0.5);  % taking the square root of the grid size to get lines and columns for a square grid
compute_method = [0 1 6];
tend = 100;
dt = 1;

% a size(computemethods) x size(grid_sizes) matrix that stores the cps of each simulation
results = zeros(size(compute_method, 2), size(grid_sizes, 2));

% Legend entries
leg = strings(1,size(compute_method, 2)); % Preallocate legend entries
figure('position', [0, 0, 600, 900])  % create new figure with specified size 
hold on;
grid on;

for i = 1:size(compute_method,2) % chose a compute method
    % Set the legend entry based on the compute method, legend is applied after the loop
    if compute_method(i) == 0
        leg(i) = sprintf('GPU');
    elseif compute_method(i) == 1
        leg(i) = sprintf('CPU (single worker)');
    else
        leg(i) = sprintf('CPU (%d workers)', compute_method(i));
    end
    fprintf('\n\n%s  ------------------------------\n',leg(i));
    % Loop through each grid size for the current compute method
    for j = 1:size(grid_sizes,2) % chose a grid size
        % check if single core cell limit is reached
        if compute_method(i) == 1 && cell_number(j) > max_single_core_cells
            results(i,j) = NaN;
        else
        % Call the LBM function and store the calulated CPS in the results matrix
        results(i,j) = LBM(grid_sizes(j), grid_sizes(j), 1, compute_method(i), dt, tend, 0, 2);
        end
    end
    plot(cell_number, results(i,:)./1e6, "o-");
end

% collect hardware information
[user,sys] = memory;
hw = sprintf(['%-6s: %s\n' ...
                '%-6s: %s\n' ...
                '%-6s: %.2f Gbyte\n' ...
                '%-6s: %s\n' ...
                '%-6s: %.2f Gbyte'], ...
    'OS', feature('GetOS'), ...
    'CPU', feature('GetCPU'), ...
    'RAM', sys.PhysicalMemory.Total/1e9, ...
    'GPU', gpuDevice().Name, ...
    'VRAM', gpuDevice().TotalMemory/1e9);

% Use logarithmic scales for both axes
yscale('log')
xscale("log")


% Adding discriptors to the plot
title('BGK, D2Q9-LBM Benchmark')
xlabel('number of cells')
ylabel('million cells per second')

legend(leg, "Location", "northwest")

% Add hardware info as a grey textbox at the top left
annotation('textbox', [0.2 0.1 0.3 0.13], ...
    'String', hw, ...
    'FitBoxToText', 'on', ...
    'EdgeColor', 'none', ...
    'FontWeight', 'normal', ...
    'FontName', 'monospaced', ...
    'Color', [0.4 0.4 0.4], ... % grey font
    'HorizontalAlignment', 'left');