- Thema Gefunden
- Bearbeitungszeit
	- Dazu eigene Stupo lesen
- Abgabe


## Betreuerin finden
- Themenlisten
- Richtlinie des FG lesen
- Betreuerin finden
- Doppeleinschreibung schwierig

### Ansprache
- lieber zu Förmlich als zu locker
- stichpunkte

## Sprechstunde
- Themenauswahl
- Passendes Modul gehört
- LP grenze vor Anmeldung

### Eigenständigkeitserklärung Lesen


## Exposee ca. 8 Wochen

## Gant chart
- Zeit Management

Kleine Zusammenfassungen

## Feedback gespräch


# Abschließende Tipps

- Richtlinien u. Vorgaben Lesen
- KI Nutzung angeben, bei Inhaltlichem in der Arbeit angeben
- Sprachliche Optimierung durch KI am Anfang in der Methodig angeben






# Bib
- Datenbank Infosystem DBIS 
- SCOPUS

- SPSS
- Einzelarbeitsräume für Abschlussarbeiten

- Schulungen


# Fragen
- gibt es ein Verteidigungsgespräch
- 