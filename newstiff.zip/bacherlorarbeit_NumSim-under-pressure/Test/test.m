% Create a 4D velocity field array
% Dimensions: [x, y, z, velocity_component]
% where velocity_component: 1=vx, 2=vy, 3=vz

% Initialize 3x3x3 grid with 3 velocity components
velocity_field = zeros(3, 3, 3, 3);

% Example: Set velocity at different points in space
% Point (1,1,1) has velocity [1, 0, 0] (moving in x-direction)
velocity_field(1, 1, 1, :) = [1, 0, 0];

% Point (2,2,2) has velocity [0, 1, 0] (moving in y-direction)  
velocity_field(2, 2, 2, :) = [2, 2, 2];

% Point (3,3,3) has velocity [0, 0, 1] (moving in z-direction)
velocity_field(3, 3, 3, :) = [0, 0, 1];

% Point (1,2,3) has velocity [1, 1, 1] (moving diagonally)
velocity_field(1, 2, 3, :) = [1, 1, 1];

% Display the velocity field
disp('Velocity field dimensions:')
disp(size(velocity_field))
velocity_field
% Access velocity at a specific point
point = [2, 2, 2];
velocity_at_point = squeeze(velocity_field(point(1), point(2), point(3), :));
fprintf('Velocity at point (%d,%d,%d): [%.1f, %.1f, %.1f]\n', ...
        point(1), point(2), point(3), velocity_at_point(1), velocity_at_point(2), velocity_at_point(3));

% Calculate speed (magnitude) at each point
speed_field = sqrt(sum(velocity_field.^2, 4));
disp('Speed at each point:')
disp(speed_field)

velocity_field_2 = velocity_field;
velocity_field_2(1, 1, 1, :) = [2, 0, 0]; % Change velocity at (1,1,1) to [2, 0, 0]



% sum(velocity_field.^2, 4)
% dot_product_field = sum(velocity_field .* velocity_field_2, 4)
constant_vector = [2, 0, 0];

% Permute constant vector to match velocity_field dimensions
constant_field = repmat(reshape(constant_vector, [1, 1, 1, 3]), [3, 3, 3, 1]);

% Now both arrays are the same size
dot_product_field = dot(velocity_field, constant_field, 4)