import numpy as np

N_grid = np.ones((3,3,9))
N_grid[1,1,:] = [0.444444444444444, 0.185185185185185, 0.111111111111111, 0.111111111111111, 0.111111111111111, 0.027777777777778, 0.027777777777778, 0.027777777777778, 0.046296296296296]
density_grid = np.ones((3,3))
geometry_grid = np.zeros((3,3), dtype=bool)
rows = 3
cols = 3



def aktualisiere_geschwindigkeit(N_gitter: np.ndarray, dichte_gitter: np.array, geometrie:np.array) -> np.ndarray:
    """
    Bestimmt die Geschwindigkeit an jedem Knotenpunkt des N_gitters und speichert diese in einem 3D numpy Array.
    Orientiert an Übungsfolie 6.

    Args:
        N_gitter (np.ndarray): Gitter auf dem die Verteilungsdichten der Knoten gespeichert werden der Form (mxnx9).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die 9 Verteilungsdichten (alpha) für jeden Knoten.

        dichte-gitter (np.ndarray): 2D Array der Form (mxn) in dem die Dichte an jedem Knotenpunkt als Float gespeichert ist.
        
        geometrie (np.ndarray): Geometrie des Objekts als 2D Boolean Array, False = leerer Raum, True = Festkörper


    Returns:
        np.ndarray: 3D numpy Array der Form (mxnx2).
            Wobei die erste und zweite Dimension die Ortskoordinaten in y- und x - Richtung der Knoten repräsentieren.
             Die dritte Dimension repräsentiert die Geschwindigkeit des Gases an diesem Knoten als 2D Vektor(in x und y Richtung).
    """
    
    # Berechnet die Geschwindigkeit an jedem Knotenpunkt anhand der Einheitsvektoren e_schlange

    # Gittervertor definieren (Achtung: die Nummerierung der Richtung ist gegen den Uhrzeigersinn!)
    e_schlang = np.array([
        [0, 0],  # Richtung 0
        [1, 0], [0, 1], [-1, 0], [0, -1],  # Richtungen 1-4, 
        [1, 1], [-1, 1], [-1, -1], [1, -1]  # Richtungen 5-8
    ], dtype=np.float64)
    
    # Berechne die Geschwindigkeit unter Verwendung der Einsteinschen-Summenkonvention,
    # sprich: jede Verteilungsdichte wird mit dem zugehörigen Einheitsvektor multipliziert und aufsummiert.
    # (N_gitter.shape = (m,n,9), e_schlang.shape = (9,2))
    geschwindigkeit_gitter = np.einsum('ijk,kl->ijl', N_gitter, e_schlang)
    # Dividieren der Geschwindigkeit durch die Dichte an jedem Knotenpunkt außerhalb der Geometrie (~geometrie = nicht Geometrie)
    geschwindigkeit_gitter[~geometrie] /= dichte_gitter[~geometrie][:, np.newaxis]
    # Wo sich die Geometrie befindet, wird die Geschwindigkeit in x und y Richtung auf 0 gesetzt
    geschwindigkeit_gitter[geometrie] = 0
    
    return geschwindigkeit_gitter



M = aktualisiere_geschwindigkeit(N_grid, density_grid, geometry_grid)
print(M[:,:,0])

print(M[:,:,1])