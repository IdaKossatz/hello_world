import numpy as np

# Create a 3D array with shape (5, 5, 3)
matrix = np.linspace(1, 5*5, 5*5).reshape((5, 5))

# print(matrix[:,:])
#print(matrix[1:-1, -1])
#print(matrix[1:-1, -2])

#matrix[1:-1,-1] = matrix[1:-1,-2] 
#print(matrix[1:-1, -1])
#print(matrix)

open_end_mask = np.zeros((5,5))
open_end_mask[:, -1] = 1; # set last row to 1
open_end_mask = (open_end_mask == 1)
#print(open_end_mask)

print(matrix[open_end_mask])
#matrix[open_end_mask] = np.roll(matrix, shift=1, axis=1)
matrix = np.roll(matrix, shift=1, axis=1)
print(matrix)
#N_3(open_end_mask) = N_3(circshift(open_end_mask, [0 -1]))