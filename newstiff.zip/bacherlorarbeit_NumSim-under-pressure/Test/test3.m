for t=1:1
    a = 1
end