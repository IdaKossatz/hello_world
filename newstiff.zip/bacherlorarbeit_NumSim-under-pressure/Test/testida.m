clc

matrix = linspace(1, 5*5, 5*5);

matrix = transpose(reshape(matrix, 5, 5));
matrix(:, end) = [0 0 0 0 0]; % set last column to 0 
disp("Starting matrix:")
disp(matrix)

open_end_mask = zeros(5, 5);
open_end_mask(:, end) = 1; % set last row to 1
open_end_mask = logical(open_end_mask)

%% Version 0
disp("Version 0:")  
matrix(open_end_mask)
matrix(open_end_mask) = matrix(circshift(open_end_mask, [0 -1]))



%% Version 1 
disp("Version 1:")
matrix = (circshift(matrix, [0 -1]));

m = matrix;
m(open_end_mask) = m(circshift(open_end_mask, [0 -1]));

matrix = m;

%% Version 2
disp("Version 2:")
matrix = linspace(1, 5*5, 5*5);

matrix = transpose(reshape(matrix, 5, 5));

open_end_mask = zeros(5, 5);
open_end_mask(:, end) = 1; % set last row to 1
open_end_mask = logical(open_end_mask);


m = matrix;
m(open_end_mask) = m(circshift(open_end_mask, [0 -1]));
matrix = m;


matrix(:,1:end-1) = (circshift(matrix(:,1:end-1), [0 -1]));


%% Version 3
disp("Version 3:")
matrix = linspace(1, 5*5, 5*5);

matrix = transpose(reshape(matrix, 5, 5));

open_end_mask = zeros(5, 5);
open_end_mask(:, end) = 1; % set last row to 1
open_end_mask = logical(open_end_mask);

last_row = matrix(:,end);
matrix = (circshift(matrix, [0 -1]));
matrix(:,end) = last_row;
