gpu(1);
disp("-------------------------------------------------\n");

gpu_cps = [];
cpu_cps = [];
for i = 1:30
    gpu_cps(end+1) = gpu(1);
end

for i = 1:30
    cpu_cps(end+1) = gpu(0);
end

gpu_cps = mean(gpu_cps);
cpu_cps = mean(cpu_cps);

disp("-------------------------------------------------\n");
disp("GPU cells per second: " + gpu_cps);
disp("CPU cells per second: " + sprintf('%.2e', cpu_cps));
disp("GPU cells per second: " + sprintf('%.2e', gpu_cps));
disp("-------------------------------------------------\n");

function cps = gpu(y)
    dimage = imread("hill.jpg");
    s = size(dimage); % get size of image
    
    if y == 1
        %disp("GPU is in use");
        dimage = gpuArray(dimage);
    else
        %disp("GPU is not in use\n");
    end

    t = tic(); % start timer
    dimage = im2double(dimage); 
    gradient = convn(dimage,ones(3)/9,"same") - convn(dimage,ones(5)/25,"same");
    amount = 5;
    sharpened = dimage + amount.*gradient;
    delta_t = toc(t); % runtime^1
    cells = s(1)*s(2)*s(3);
    % imshow(imresize([dimage,sharpened],0.7));
    % title("Original image (left) vs sharpened image (right)");
    cps = (cells / delta_t); % cells per second
end


