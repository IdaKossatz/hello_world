x = [1,2,2,1].'
y = [1,1,2,2].'

A = zeros(5,3);
A(2:4, 2:4, 2:4) = 1;
[row_indices, col_indices, z] = ind2sub(size(A), find(A));

row_indices
col_indices

view(3)
hold on
shp = alphaShape(row_indices, col_indices, z);
plot(shp,'FaceColor','#5c5f77', 'EdgeColor', "#4c4f69");
xlim([0 5])
ylim([0 5])
zlim([0 5])
