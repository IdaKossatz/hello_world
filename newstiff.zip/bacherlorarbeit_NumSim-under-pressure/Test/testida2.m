
clc
close all

lines = 10;
cols = 15;
depth = 10;
bb_mask = repmat(sphere(16), [1 1 depth]);
bb_mask = zeros(lines,cols,depth);
bb_mask(3:end-2, 3:end-2, 3:end-2) = 1;
bb_mask
size(bb_mask)

u = zeros(lines,cols,depth);
size(u)
v = ones(lines,cols, depth);

%u = zeros(lines,cols);
size(u);
%v = ones(lines,cols);
w = zeros(lines,cols, depth);


%[startX,startY,startZ] = meshgrid(1,1:20:lines+20,1:20:depth+20);
[startX,startY,startZ] = meshgrid(1,linspace(1,lines,6),linspace(1,depth,10));


%dim2 = streamline(v,u,startX,startY);
dim3 = streamline(v,u,w,startX,startY,startZ);
view(3)
set(gca,'DataAspectRatio',[1 1 1])

%scatter3(bb_maskfilled')
[i, j, k] = ind2sub(size(bb_mask), find(bb_mask));

% Plot the 3D scatter
% figure;
% scatter3(j, i, k, 20, 'filled'); % (X=cols, Y=lines, Z=depth)